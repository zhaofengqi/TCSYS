#ifndef TCSYS_Config_H
#define TCSYS_Config_H
#include <stdio.h>

//�������Ͷ��� ����CPU �ͱ������޸�
#define Byte unsigned char
#define SByte char
#define UInt16 unsigned short
#define Int16 short
#define UInt32 unsigned int
#define Int32 int
#define Single float
#define Double double
#define Bool unsigned char
#define TC_TRUE 1
#define TC_FALSE 0


#define CriticalIn  __disable_irq();
#define CriticalOut __enable_irq();

#define TaskIDType Byte
#define TaskIDNone 0xFF

#define DevTimerMax 0xFFFFFF

#define TaskTimeMax 0xFFFFFF
#define TaskTimeOneUs 1UL
#define TaskTimeMs(x) (TaskTimeOneUs*1000*x)
#define TaskTimeS(x)  (TaskTimeOneUs*1000000*x)
#define TaskTimeMinute(x) (TaskTimeOneUs*1000000*60*x)
#define TaskTimeHour(x) (TaskTimeOneUs*1000000*60*60*x)
#define TaskCPUTimeCalculateNumMaxBit 5
#define TaskCPUTimeCalculateNumMax (1<<TaskCPUTimeCalculateNumMaxBit)

#define DevCountMax 20
#endif
