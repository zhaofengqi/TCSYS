#include "../TCSYS_Config.h"
#include "../Task/TC_Task.h"
#include "Debug.h"
#include "AppProtocolController.h"

#include <stdlib.h>
#include <string.h>
static const char* TaskName="AppProtocolControler";
static const SByte *ProtocolCMD=(void*)"AppProtocolControler";
static TaskIDType TaskID=TaskIDNone;
#define ProtocolDEVMax 10
#define ProtocolQueueCountMax 5
#define ProtocolQueueIDNone 0xFFFF
#define ProtocolRecvBufMax 1000



typedef struct
{
	const DevNodeStruct* DEV;
	const AppProtocolQueueStruct *QueueList[ProtocolQueueCountMax];
	Byte QueueCount;
}AppProtocolListUnit;

typedef struct
{
	AppProtocolListUnit AppProtocolList[ProtocolDEVMax];
	Byte TempRecvBuf[ProtocolRecvBufMax];
	Byte Count;
}AppProtocolManageStruct;

AppProtocolManageStruct AppProtocolManage;

Bool AppProtocolRegeist(const DevNodeStruct* DEV,const AppProtocolQueueStruct* AppQueue)
{
	UInt16 i=0;
	UInt16 DEVIndex=0xff,QueueIndex=0xff;
	if(DEV!=NULL)
	{
		for(i=0;i<AppProtocolManage.Count;i++)
		{
			if(AppProtocolManage.AppProtocolList[i].DEV==DEV)
			{
				DEVIndex=i;
			}
		}
		if(DEVIndex==0xff)
		{
			if(AppProtocolManage.Count<ProtocolDEVMax)
			{
				DEVIndex=AppProtocolManage.Count;
				AppProtocolManage.Count++;
				AppProtocolManage.AppProtocolList[DEVIndex].DEV=DEV;
				DEV_Init(DEV);
				DEV_Open(DEV,TaskID);	
			}
		}
		
		if(DEVIndex!=0xff)
		{
			for(i=0;i<AppProtocolManage.AppProtocolList[DEVIndex].QueueCount;i++)
			{
				if(AppProtocolManage.AppProtocolList[DEVIndex].QueueList[i]==AppQueue)
				{
					QueueIndex=i;
				}
			}
			if(QueueIndex==0xff)
			{
				if(AppProtocolManage.AppProtocolList[DEVIndex].QueueCount<ProtocolQueueCountMax)
				{
					QueueIndex=AppProtocolManage.AppProtocolList[DEVIndex].QueueCount;
					AppProtocolManage.AppProtocolList[DEVIndex].QueueCount++;
					AppProtocolManage.AppProtocolList[DEVIndex].QueueList[QueueIndex]=AppQueue;
				}
			}
		}
	}
	if((DEVIndex==0xff)||(QueueIndex==0xff))
	{
		return TC_FALSE;
	}
	return TC_TRUE;
}

static void CMDDo(Byte* Param)
{
	SByte SendBuf[100];
	sprintf(SendBuf,"%s--%s\n","AppProtocolControler",Param);
	DebugOut(SendBuf,strlen(SendBuf),TC_TRUE);
  free(Param);
}
void AppProtocolControlertTask(void* TaskParam,void *TaskInfo)
{
	UInt16 i,j,DEVUnreadCount,QueueWriteCount;
	TC_QueueStruct* PQueue=NULL;
	TaskStateInfoStruct * PTaskInfo=(TaskStateInfoStruct *)TaskInfo;
	for(i=0;i<AppProtocolManage.Count;i++)
	{
		DEVUnreadCount=0;			
		DEV_IOControl(AppProtocolManage.AppProtocolList[i].DEV,TaskID,DevCMD_GetUnreadCount,NULL,&DEVUnreadCount);			
		if(DEVUnreadCount>0)
		{
			if(DEVUnreadCount>ProtocolRecvBufMax)
			{
				DEVUnreadCount=ProtocolRecvBufMax;
			}
			DEVUnreadCount=DEV_Read(AppProtocolManage.AppProtocolList[i].DEV,TaskID,AppProtocolManage.TempRecvBuf,DEVUnreadCount);		

		}
		for(j=0;j<AppProtocolManage.AppProtocolList[i].QueueCount;j++)
		{
			PQueue=AppProtocolManage.AppProtocolList[i].QueueList[j]->ReceiveQueue;
			QueueWriteCount=DEVUnreadCount;
			if(QueueWriteCount>(PQueue->Size - PQueue->WritePtr))
			{	
				QueueWriteCount=PQueue->Size - PQueue->WritePtr;
			}
			if(QueueWriteCount>0)
			{
				TC_QueueWrite(PQueue,AppProtocolManage.TempRecvBuf,QueueWriteCount,TC_FALSE,TC_TRUE);
			}
			if(AppProtocolManage.AppProtocolList[i].QueueList[j]->ProtocolTask!=NULL)
			{
				AppProtocolManage.AppProtocolList[i].QueueList[j]->ProtocolTask(AppProtocolManage.AppProtocolList[i].QueueList[j]->TaskParam,PTaskInfo->TaskInterval);
			}
			QueueWriteCount=0;
			PQueue=AppProtocolManage.AppProtocolList[i].QueueList[j]->SendQueue;		
			if(PQueue->WritePtr>0)
			{
				if(PQueue->WritePtr>QueueWriteCount)
				{
					QueueWriteCount=PQueue->WritePtr;
				}
				QueueWriteCount=DEV_Write(AppProtocolManage.AppProtocolList[i].DEV,TaskID,PQueue->Memory,PQueue->WritePtr);
				TC_QueueScoll(PQueue,QueueWriteCount,FALSE);
			}
		}
	}
}
void AppProtocolControllerInit(void)
{
	DebugCmdParamStruct CMDReg;
	CMDReg.CMD=(void*)ProtocolCMD;
	CMDReg.CMDLength=strlen(CMDReg.CMD);
	CMDReg.Callback=CMDDo;
	
	
	DebugRegistCmd(&CMDReg);
	TaskID=TC_Task_Add(AppProtocolControlertTask,TaskName);
}
