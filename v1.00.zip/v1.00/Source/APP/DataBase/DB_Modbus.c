#define DB_Modbus_Var
#include "DB_Modbus.h"
#include "../DataBase/DB_Modbus.h"
typedef enum
{
	DB_ModbusFuncEnum_None=0x00,
	DB_ModbusFuncEnum_ReadCircle=0x01,
	DB_ModbusFuncEnum_ReadInputBinSignal=0x02,
	DB_ModbusFuncEnum_ReadInsideReg=0x03,
	DB_ModbusFuncEnum_ReadInputReg=0x04,
	DB_ModbusFuncEnum_WriteCircle=0x05,
	DB_ModbusFuncEnum_WriteSingleReg=0x06,
	DB_ModbusFuncEnum_WriteMutiCircle=0x0f,
	DB_ModbusFuncEnum_WriteMutiReg=0x10,
	DB_ModbusFuncEnum_ReadWriteMutiReg=0x17,
}DB_ModbusFuncEnum;
static DBModbusErrorEnum WriteData(Byte Func,UInt16 Addr,UInt16 Count,Byte*InputBuf,DBModbusDataTypeEnum DataType);
static DBModbusErrorEnum ReadData(Byte Func,UInt16 Addr,UInt16 Count,Byte*OutputBuf,UInt16*OutPutSize,DBModbusDataTypeEnum DataType);

static DBModbusDataStruct DBModbusData;

const DBModbusInterfaceStruct DBModbusInterface=
{
	.ReadData=ReadData,
	.WriteData=WriteData
};
static inline UInt16 HexByteToAscii(Byte HexByte)
{
	UInt16 Ret=0;
	if((HexByte>>8)<10)
	{
		Ret+=0x30;
	}
	else
	{
		Ret+=0x41-10;
	}
	Ret<<=8;
	if((HexByte&0xF)<10)
	{
		Ret+='0';
	}
	else
	{
		Ret+='A'-10;
	}
	return Ret;
}

static inline Byte AsciiToHexByte(Byte* ASCIIBuf)
{
	Byte Ret=0;
	if((ASCIIBuf[0])>='0'&&(ASCIIBuf[0])<='9')
	{
		Ret+=ASCIIBuf[0]-'0';
	}
	if((ASCIIBuf[0])>='a'&&(ASCIIBuf[0])<='f')
	{
		Ret+=ASCIIBuf[0]-'a'+10;
	}
	if((ASCIIBuf[0])>='A'&&(ASCIIBuf[0])<='F')
	{
		Ret+=ASCIIBuf[0]-'A'+10;
	}
	Ret<<=4;
	if((ASCIIBuf[1])>='0'&&(ASCIIBuf[1])<='9')
	{
		Ret+=ASCIIBuf[1]-'0';
	}
	if((ASCIIBuf[1])>='a'&&(ASCIIBuf[1])<='f')
	{
		Ret+=ASCIIBuf[1]-'a'+10;
	}
	if((ASCIIBuf[1])>='A'&&(ASCIIBuf[1])<='F')
	{
		Ret+=ASCIIBuf[1]-'A'+10;
	}
	return Ret;
}

static DBModbusErrorEnum ReadCircle(UInt16 Addr,UInt16 Count,Byte*OutputBuf,UInt16 *OutPutSize,DBModbusDataTypeEnum DataType)
{
	UInt16 i,DBByteIndex,DBBitIndex,OutputBitIndex=0,OutputByteIndex=0,OutputData=0;
	DBModbusErrorEnum ErrorRet=DBModbusErrorEnum_00;
	if(Count>2000)
	{
		ErrorRet=DBModbusErrorEnum_03;
	}
	else if(
		  ((Addr>CircleAddrStart)||(Addr==CircleAddrStart))&&
		  ((Addr+Count)<=(CircleAddrStart+CircleBitCountMax))
	)
	{
		DBByteIndex=(Addr-CircleAddrStart)>>3;
		DBBitIndex=(Addr-CircleAddrStart)&0x07;
		
		for(i=0;i<Count;i++)
		{
			OutputData|=((DBModbusData.CircleBitData[DBByteIndex]>>DBBitIndex)&0x1)<<OutputBitIndex;
			DBBitIndex++;
			if(DBBitIndex>=8)
			{		
				DBByteIndex++;
				DBBitIndex=0;
			}		
			OutputBitIndex++;
			if(OutputBitIndex>=8)
			{	
				if(DataType==DBModbusDataTypeEnum_RTU)
				{
					OutputBuf[OutputByteIndex]=OutputData;
					OutputData=0;				
					OutputByteIndex++;
				}
				else 
				{
					OutputData=HexByteToAscii((Byte)OutputData);
					OutputBuf[OutputByteIndex++]=OutputData>>8;
					OutputBuf[OutputByteIndex]=OutputData&0xFF;
					OutputData=0;				
					OutputByteIndex++;
				}
				OutputBitIndex=0;
			}
		}
		if(OutputBitIndex>0)
		{
			OutputBuf[OutputByteIndex]=OutputData;
			OutputByteIndex++;	
		}
		
		*OutPutSize=OutputByteIndex;
	}
	else
	{
		*OutPutSize=0;
		ErrorRet=DBModbusErrorEnum_02;
	}
	return ErrorRet;
}
static inline DBModbusErrorEnum ReadInputBinSignal(UInt16 Addr,UInt16 Count,Byte* OutputBuf,UInt16* OutPutSize,DBModbusDataTypeEnum DataType)
{
	UInt16 i,DBByteIndex,DBBitIndex,OutputBitIndex=0,OutputByteIndex=0,OutputData=0;
	DBModbusErrorEnum ErrorRet=DBModbusErrorEnum_00;
	if(Count>0x7D0)
	{
		ErrorRet=DBModbusErrorEnum_03;
	}
	else if(
			((Addr>InputBinSignalAddrStart)||(Addr==InputBinSignalAddrStart))&&
			((Addr+Count)<=(InputBinSignalAddrStart+InputBinSignalCountMax))
	)
	{
		DBByteIndex=(Addr-CircleAddrStart)>>3;
		DBBitIndex=(Addr-CircleAddrStart)&0x07;
		
		for(i=0;i<Count;i++)
		{
			OutputData|=((DBModbusData.InputBinSignalData[DBByteIndex]>>DBBitIndex)&0x1)<<OutputBitIndex;
			DBBitIndex++;
			if(DBBitIndex>=8)
			{		
				DBByteIndex++;
				DBBitIndex=0;
			}		
			OutputBitIndex++;
			if(OutputBitIndex>=8)
			{	
				if(DataType==DBModbusDataTypeEnum_RTU)
				{
					OutputBuf[OutputByteIndex]=OutputData;
					OutputData=0;				
					OutputByteIndex++;
				}
				else 
				{
					OutputData=HexByteToAscii((Byte)OutputData);
					OutputBuf[OutputByteIndex++]=OutputData>>8;
					OutputBuf[OutputByteIndex]=OutputData&0xFF;
					OutputData=0;				
					OutputByteIndex++;
				}
				OutputBitIndex=0;
			}
		}
		if(OutputBitIndex>0)
		{
			OutputBuf[OutputByteIndex]=OutputData;
		}
		if(OutputBitIndex!=0)
		{
			OutputByteIndex++;
		}
		*OutPutSize=OutputByteIndex;
	}
	else
	{
		*OutPutSize=0;
		ErrorRet=DBModbusErrorEnum_02;
	}
	return ErrorRet;
}
static inline DBModbusErrorEnum ReadInputRegs(UInt16 Addr,UInt16 Count,Byte*OutputBuf,UInt16*OutPutSize,DBModbusDataTypeEnum DataType)
{
	UInt16 i,OutputByteIndex=0,OutputData=0;
	DBModbusErrorEnum ErrorRet=DBModbusErrorEnum_00;
	if(Count>0x7D)
	{
		ErrorRet=DBModbusErrorEnum_03;
	}
	else if(
			((Addr>InputBinSignalAddrStart)||(Addr==InputBinSignalAddrStart))&&
			((Addr+Count)<=(InputBinSignalAddrStart+InputRegCountMax))
	)
	{
		for(i=Addr;i<Addr+Count;i++)
		{
			if(DataType==DBModbusDataTypeEnum_RTU)
			{
				OutputBuf[OutputByteIndex++]=DBModbusData.InputRegs[i]>>8;
				OutputBuf[OutputByteIndex++]=DBModbusData.InputRegs[i]&0xff;
			}
			else
			{
				OutputData=HexByteToAscii(DBModbusData.InputRegs[i]>>8);
				OutputBuf[OutputByteIndex++]=OutputData>>8;
				OutputBuf[OutputByteIndex++]=OutputData&0xff;	
				OutputData=HexByteToAscii(DBModbusData.InputRegs[i]&0xff);
				OutputBuf[OutputByteIndex++]=OutputData>>8;
				OutputBuf[OutputByteIndex++]=OutputData&0xff;
			}
		}
		*OutPutSize=OutputByteIndex;
	}
	else
	{
		*OutPutSize=0;
		ErrorRet=DBModbusErrorEnum_02;
	}
	return ErrorRet;
}
 
static inline DBModbusErrorEnum ReadInsideRegs(UInt16 Addr,UInt16 Count,Byte*OutputBuf,UInt16*OutPutSize,DBModbusDataTypeEnum DataType)
{
	UInt16 i,OutputByteIndex=0,OutputData=0;
	DBModbusErrorEnum ErrorRet=DBModbusErrorEnum_00;
	if(Count>0x7D)
	{
		ErrorRet=DBModbusErrorEnum_03;
	}
	else if(
			((Addr>InsideRegsAddrStart)||(Addr==InsideRegsAddrStart))&&
			((Addr+Count)<=(InsideRegsAddrStart+InsideRegsCountMax))
	)
	{
		for(i=Addr;i<Addr+Count;i++)
		{
			if(DataType==DBModbusDataTypeEnum_RTU)
			{
				OutputBuf[OutputByteIndex++]=DBModbusData.InputRegs[i]>>8;
				OutputBuf[OutputByteIndex++]=DBModbusData.InputRegs[i]&0xff;
			}
			else
			{
				OutputData=HexByteToAscii(DBModbusData.InputRegs[i]>>8);
				OutputBuf[OutputByteIndex++]=OutputData>>8;
				OutputBuf[OutputByteIndex++]=OutputData&0xff;	
				OutputData=HexByteToAscii(DBModbusData.InputRegs[i]&0xff);
				OutputBuf[OutputByteIndex++]=OutputData>>8;
				OutputBuf[OutputByteIndex++]=OutputData&0xff;
			}
		}
		*OutPutSize=OutputByteIndex;
	}
	else
	{
		*OutPutSize=0;
		ErrorRet=DBModbusErrorEnum_02;
	}
	return ErrorRet;
}
static inline DBModbusErrorEnum WriteCircle(UInt16 Addr,Byte*InputBuf,DBModbusDataTypeEnum DataType)
{
	UInt16 DBByteIndex,DBBitIndex,InputData=0;
	DBModbusErrorEnum ErrorRet=DBModbusErrorEnum_00;
	if(
			((Addr>CircleAddrStart)||(Addr==CircleAddrStart))&&
			(Addr<=(CircleAddrStart+CircleBitCountMax))
	)
	{
		DBByteIndex=(Addr-CircleAddrStart)>>3;
		DBBitIndex=(Addr-CircleAddrStart)&0x07;

		if(DataType==DBModbusDataTypeEnum_RTU)
		{
			InputData=InputBuf[0];
			InputData<<=8;
			InputData+=InputBuf[1];
		}
		else
		{
			InputData=AsciiToHexByte(&InputBuf[0]);
			InputData<<=8;
			InputData+=AsciiToHexByte(&InputBuf[2]);
		}
		if(InputData==0xFF00)
		{
			DBModbusData.CircleBitData[DBByteIndex]|=1<<DBBitIndex;
		}
		else if(InputData==0x0000)
		{
			DBModbusData.CircleBitData[DBByteIndex]&=~(1<<DBBitIndex);
		}
		else
		{
			ErrorRet=DBModbusErrorEnum_03;
		}
	}
	else
	{
		ErrorRet=DBModbusErrorEnum_02;
	}
	return ErrorRet;
}

static inline DBModbusErrorEnum WriteCircles(UInt16 Addr,UInt16 Count,Byte*InputBuf,DBModbusDataTypeEnum DataType)
{
	UInt16 i,DBByteIndex,DBBitIndex,InputByteIndex=0,InputBitIndex=0;
	DBModbusErrorEnum ErrorRet=DBModbusErrorEnum_00;
	Bool InputBit;
	if(Count>0x7B0)
	{
		ErrorRet=DBModbusErrorEnum_03;
	}
	if(
			((Addr>CircleAddrStart)||(Addr==CircleAddrStart))&&
			((Addr+Count)<=(CircleAddrStart+CircleBitCountMax))
	)
	{
		DBByteIndex=(Addr-CircleAddrStart)>>3;
		DBBitIndex=(Addr-CircleAddrStart)&0x07;
		for(i=0;i<Count;i++)
		{
			if(DataType==DBModbusDataTypeEnum_RTU)
			{
				InputBit=(InputBuf[InputByteIndex]>>InputBitIndex)&0x01;
			}
			else
			{
				InputBit=AsciiToHexByte(&InputBuf[InputByteIndex<<1]);
				InputBit>>=InputBitIndex;
				InputBit&=0x01;
			}
			if(InputBit)
			{
				DBModbusData.CircleBitData[DBByteIndex]|=InputBit<<DBByteIndex;
			}
			else
			{
				DBModbusData.CircleBitData[DBByteIndex]&=~InputBit<<DBByteIndex;
			}
			InputBitIndex++;
			if(InputBitIndex>=8)
			{
				InputBitIndex=0;
				InputByteIndex++;
			}
			DBBitIndex++;
			if(DBBitIndex>=8)
			{
				DBBitIndex=0;
				DBByteIndex++;
			}	
		}			
	}
	else
	{
		ErrorRet=DBModbusErrorEnum_02;
	}
	return ErrorRet;
}
static inline DBModbusErrorEnum WriteInsideRegs(UInt16 Addr,UInt16 Count,Byte*InputBuf,DBModbusDataTypeEnum DataType)
{
	UInt16 i,InputData;
	DBModbusErrorEnum ErrorRet=DBModbusErrorEnum_00;
	if(Count>0x78)
	{
		ErrorRet=DBModbusErrorEnum_03;
	}
	else if(
			((Addr>InsideRegsAddrStart)||((Addr==InsideRegsAddrStart)))&&
			((Addr+Count)<=(InsideRegsAddrStart+InsideRegsCountMax))
	)
	{
		for(i=Addr;i<Addr+Count;i++)
		{
			if(DataType==DBModbusDataTypeEnum_RTU)
			{
				InputData=InputBuf[0];
				InputData<<=8;
				InputData+=InputBuf[1];
			}
			else
			{
				InputData=AsciiToHexByte(&InputBuf[0]);
				InputData<<=8;
				InputData+=AsciiToHexByte(&InputBuf[2]);
			}
			DBModbusData.InsideRegs[Addr+i]=InputData;
		
		}	
	}
	else
	{
		ErrorRet=DBModbusErrorEnum_02;
	}
	return ErrorRet;
}

static DBModbusErrorEnum ReadData(Byte Func,UInt16 Addr,UInt16 Count,Byte*OutputBuf,UInt16*OutPutSize,DBModbusDataTypeEnum DataType)
{
	DBModbusErrorEnum ErrorRet=DBModbusErrorEnum_01;
	switch(Func)
	{
		case (Byte)DB_ModbusFuncEnum_ReadCircle:
			ErrorRet=ReadCircle(Addr,Count,OutputBuf,OutPutSize,DataType);
		break;
		case (Byte)DB_ModbusFuncEnum_ReadInputBinSignal:
			ErrorRet=ReadInputBinSignal(Addr,Count,OutputBuf,OutPutSize,DataType);
		break;
		case (Byte)DB_ModbusFuncEnum_ReadInsideReg:
			ErrorRet=ReadInsideRegs(Addr,Count,OutputBuf,OutPutSize,DataType);
		break;
		case (Byte)DB_ModbusFuncEnum_ReadInputReg:
			ErrorRet=ReadInputRegs(Addr,Count,OutputBuf,OutPutSize,DataType);
		break;
	}
	return ErrorRet;
}
static DBModbusErrorEnum WriteData(Byte Func,UInt16 Addr,UInt16 Count,Byte*InputBuf,DBModbusDataTypeEnum DataType)
{
	DBModbusErrorEnum ErrorRet=DBModbusErrorEnum_01;
	switch(Func)
	{
	 	case (Byte)DB_ModbusFuncEnum_WriteCircle:
			ErrorRet=WriteCircle(Addr,InputBuf,DataType);
		break;
		case (Byte)DB_ModbusFuncEnum_WriteSingleReg:
			ErrorRet=WriteInsideRegs(Addr,1,InputBuf,DataType);
		break;
		case (Byte)DB_ModbusFuncEnum_WriteMutiCircle:
			ErrorRet=WriteCircles(Addr,Count,InputBuf,DataType);
		break;
		case (Byte)DB_ModbusFuncEnum_WriteMutiReg:
			ErrorRet=WriteInsideRegs(Addr,Count,InputBuf,DataType);
		break;
	}
	return ErrorRet;
}
void DBModbusInit()
{
	UInt16 i=0;
	for(i=0;i<InputRegCountMax;i++)
	{
		DBModbusData.InputRegs[i]=i;
		DBModbusData.InsideRegs[i]=i;
	}
}