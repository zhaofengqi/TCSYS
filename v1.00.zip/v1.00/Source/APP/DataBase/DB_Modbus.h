#ifndef DB_Modbus_H
#define DB_Modbus_H
#include "DataBase.h"
#define CircleAddrStart 0x0000
#define CircleDataMax 3u
#define CircleBitCountMax (CircleDataMax*8)

#define InputBinSignalAddrStart 0x0000
#define InputBinSignalDataMax 3
#define InputBinSignalCountMax (InputBinSignalDataMax*8)
#define InputRegAddrStart 0x0000u
#define InputRegCountMax 16u
#define InsideRegsAddrStart 0x0000u
#define InsideRegsCountMax 16u

typedef enum
{
	DBModbusDataTypeEnum_RTU,
	DBModbusDataTypeEnum_ASCII,
}DBModbusDataTypeEnum;

typedef enum
{
	DBModbusErrorEnum_00=0x00,
	DBModbusErrorEnum_01=0x01,
	DBModbusErrorEnum_02=0x02,
	DBModbusErrorEnum_03=0x03,
	DBModbusErrorEnum_04=0x04
}DBModbusErrorEnum;

typedef struct 
{
	Byte CircleBitData[CircleDataMax];
	Byte InputBinSignalData[InputBinSignalDataMax];
	UInt16 InputRegs[InputRegCountMax];
	UInt16 InsideRegs[InsideRegsCountMax];
}DBModbusDataStruct;
typedef struct
{
	DBModbusErrorEnum (*WriteData)(Byte Func,UInt16 Addr,UInt16 Count,Byte*InputBuf,DBModbusDataTypeEnum DataType);
	DBModbusErrorEnum (*ReadData)(Byte Func,UInt16 Addr,UInt16 Count,Byte*OutputBuf,UInt16*OutPutSize,DBModbusDataTypeEnum DataType);
}DBModbusInterfaceStruct;
void DBModbusInit(void);
void DBModbusInit(void);
#ifndef DB_Modbus_Var
extern const DBModbusInterfaceStruct DBModbusInterface;
extern const DBModbusDataStruct DBModbusData;

#endif
#endif
