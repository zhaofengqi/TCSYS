#include "../TCSYS_Config.h"
#include "../Device/DEV.h"
#include "../Task/TC_Task.h"
#include "Test.h"
#include "Debug.h"
#include "Test.h"
#include "AppProtocolController.h"
#include <string.h>

typedef struct
{
    unsigned int    CardType;       /*!< SDHC, SD, or MMC */
    unsigned int    RCA;            /*!< Relative card address */
    unsigned char   IsCardInsert;   /*!< Card insert state */
    unsigned int    totalSectorN;   /*!< Total sector number */
    unsigned int    diskSize;       /*!< Disk size in K bytes */
    int             sectorSize;     /*!< Sector size in bytes */
}SDInfoStruct;   
SDH_INFO_T SDInfo;

uint32_t Swap32(uint32_t val)
{
    uint32_t buf;

    buf = val;
    val <<= 24;
    val |= (buf<<8) & 0xff0000ul;
    val |= (buf>>8) & 0xff00ul;
    val |= (buf>>24)& 0xfful;
    return val;
}

void sdinit()
{
	uint32_t buf;
		uint32_t tmp0 = 0ul, tmp1= 0ul,resp=0,i;
 uint32_t readbuf[5];
	uint32_t result[5];
uint32_t  R_LEN, C_Size, MULT, size;
 SYS_UnlockReg();
 CLK_EnableModuleClock(SDH0_MODULE);//ʹ��UART0 ʱ��
 CLK_SetModuleClock(SDH0_MODULE, CLK_CLKSEL0_SDH0SEL_HIRC, CLK_CLKDIV0_SDH0(31));//SD0 ʱ�� HIRC/32 = 12MHz/32=375K
 
 SYS->GPB_MFPL &= ~(SYS_GPB_MFPL_PB4MFP_Msk | SYS_GPB_MFPL_PB5MFP_Msk);
 SYS->GPB_MFPL |= (SYS_GPB_MFPL_PB4MFP_SD0_DAT2 | SYS_GPB_MFPL_PB5MFP_SD0_DAT3);

 SYS->GPE_MFPL &= ~(SYS_GPE_MFPL_PE2MFP_Msk | SYS_GPE_MFPL_PE3MFP_Msk | SYS_GPE_MFPL_PE6MFP_Msk | SYS_GPE_MFPL_PE7MFP_Msk);
 SYS->GPE_MFPL |= (SYS_GPE_MFPL_PE2MFP_SD0_DAT0 | SYS_GPE_MFPL_PE3MFP_SD0_DAT1 | SYS_GPE_MFPL_PE6MFP_SD0_CLK | SYS_GPE_MFPL_PE7MFP_SD0_CMD);
	
 SYS->GPD_MFPH &= ~(SYS_GPD_MFPH_PD13MFP_Msk);
 SYS->GPD_MFPH |= (SYS_GPD_MFPH_PD13MFP_SD0_nCD );
	
 SYS_LockReg();
 SYS_ResetModule(SDH0_RST); 
	

 
 //��λ��ʹ��SD DMA
    SDH0->DMACTL = SDH_DMACTL_DMARST_Msk;
    while ((SDH0->DMACTL & SDH_DMACTL_DMARST_Msk) == SDH_DMACTL_DMARST_Msk){}
    SDH0->DMACTL = SDH_DMACTL_DMAEN_Msk;

 //��λ��ʹ��SD
    SDH0->GCTL = SDH_GCTL_GCTLRST_Msk | SDH_GCTL_SDEN_Msk;
    while ((SDH0->GCTL & SDH_GCTL_GCTLRST_Msk) == SDH_GCTL_GCTLRST_Msk){}	
		SDH0->GCTL = SDH_GCTL_SDEN_Msk;//ʹ��SD
		
    //SDH0->INTEN |= SDH_INTEN_CDSRC_Msk;    
		//SDH0->INTEN |= SDH_INTEN_CDIEN_Msk;    
		SDH0->CTL |= SDH_CTL_CTLRST_Msk;
			
 SDH0->DMACTL = SDH_DMACTL_DMAEN_Msk;
 SDH0->GCTL = SDH_GCTL_GCTLRST_Msk | SDH_GCTL_SDEN_Msk;	
 SDH0->GINTEN = 0ul;
 SDH0->CTL &= ~SDH_CTL_SDNWR_Msk;
 SDH0->CTL |=  0x09ul << SDH_CTL_SDNWR_Pos;   /* set SDNWR = 9 */
 SDH0->CTL &= ~SDH_CTL_BLKCNT_Msk;
 SDH0->CTL |=  0x01ul << SDH_CTL_BLKCNT_Pos;  /* set BLKCNT = 1 */
 SDH0->CTL &= ~SDH_CTL_DBW_Msk;               /* SD 1-bit data bus */
			
    while ((SDH0->CTL & SDH_CTL_CTLRST_Msk) == SDH_CTL_CTLRST_Msk){}
			while(SDH0->INTSTS & SDH_INTSTS_CDIF_Msk)
			{
			SDH0->INTSTS = SDH_INTSTS_CDIF_Msk;
			}
			
	//��74��ʱ��
	 SDH0->CTL |= SDH_CTL_CLK74OEN_Msk;
   while ((SDH0->CTL & SDH_CTL_CLK74OEN_Msk) == SDH_CTL_CLK74OEN_Msk){}
			
	//��CMD0
  buf = (SDH0->CTL&(~SDH_CTL_CMDCODE_Msk))|(0x00ul << 8ul)|(SDH_CTL_COEN_Msk);
		 SDH0->CMDARG =0;	
	SDH0->CTL=buf;
	while ((SDH0->CTL & SDH_CTL_COEN_Msk) == SDH_CTL_COEN_Msk){}
//
  buf= (SDH0->CTL & (~SDH_CTL_CMDCODE_Msk)) | (8ul << 8ul) | (SDH_CTL_COEN_Msk | SDH_CTL_RIEN_Msk);
  SDH0->CMDARG =0x00000155ul;	
	SDH0->CTL=buf;
		while ((SDH0->CTL & SDH_CTL_RIEN_Msk) == SDH_CTL_RIEN_Msk) {} 
			
	while((resp&0x00800000)!=0x00800000)
	{			
	//��CMD55
  buf= (SDH0->CTL & (~SDH_CTL_CMDCODE_Msk)) | (55ul << 8ul) | (SDH_CTL_COEN_Msk | SDH_CTL_RIEN_Msk);
  SDH0->CMDARG =0;	
	SDH0->CTL=buf;
		while ((SDH0->CTL & SDH_CTL_RIEN_Msk) == SDH_CTL_RIEN_Msk) {} 
		      tmp1 = SDH0->RESP1 & 0xfful;
    tmp0 = SDH0->RESP0 & 0xful;	
			SDH0->INTSTS = SDH_INTSTS_CRCIF_Msk;//R2 CRC7�������
	//�� ACMD41

	buf= (SDH0->CTL & (~SDH_CTL_CMDCODE_Msk)) | (41ul << 8ul) | (SDH_CTL_COEN_Msk | SDH_CTL_RIEN_Msk);
	SDH0->CMDARG =0x40ff8000ul;	
 	SDH0->CTL=buf;
		while ((SDH0->CTL & SDH_CTL_RIEN_Msk) == SDH_CTL_RIEN_Msk) {}  
      tmp1 = SDH0->RESP1 & 0xfful;
    tmp0 = SDH0->RESP0 & 0xful;	
  SDH0->INTSTS = SDH_INTSTS_CRCIF_Msk;//R2 CRC7�������
			resp=SDH0->RESP0 ;
		}
	
	//�� CID
		SDH0->CMDARG = 0;
    buf = (SDH0->CTL&(~SDH_CTL_CMDCODE_Msk))|(2ul << 8)|(SDH_CTL_COEN_Msk | SDH_CTL_R2EN_Msk);
    SDH0->CTL = buf;
		while ((SDH0->CTL & SDH_CTL_R2EN_Msk) == SDH_CTL_R2EN_Msk){};
			
	//��ȡRCA
	buf= (SDH0->CTL & (~SDH_CTL_CMDCODE_Msk)) | (3ul << 8ul) | (SDH_CTL_COEN_Msk | SDH_CTL_RIEN_Msk);
	SDH0->CMDARG =0;	
 	SDH0->CTL=buf;
			while ((SDH0->CTL & SDH_CTL_RIEN_Msk) == SDH_CTL_RIEN_Msk) {}  
	SDInfo.RCA = (SDH0->RESP0 << 8) & 0xffff0000;


	//�� CSD
		SDH0->CMDARG = SDInfo.RCA;
    buf = (SDH0->CTL&(~SDH_CTL_CMDCODE_Msk))|(9ul << 8)|(SDH_CTL_COEN_Msk | SDH_CTL_R2EN_Msk);
    SDH0->CTL = buf;
		while ((SDH0->CTL & SDH_CTL_R2EN_Msk) == SDH_CTL_R2EN_Msk){};
		for (i=0ul; i<5ul; i++)
    {
      readbuf[i] = Swap32(SDH0->FB[i]);
    }
    for (i=0ul; i<4ul; i++)
    {
      result[i] = ((readbuf[i] & 0x00fffffful)<<8) | ((readbuf[i+1ul] & 0xff000000ul)>>24);
    }
        if ((result[0] & 0xc0000000) != 0x0ul)
        {
            C_Size = ((result[1] & 0x0000003ful) << 16) | ((result[2] & 0xffff0000ul) >> 16);
            size = (C_Size+1ul) * 512ul;    /* Kbytes */

            SDInfo.diskSize = size;
            SDInfo.totalSectorN = size << 1;
        }
        else
        {
            R_LEN = (result[1] & 0x000f0000ul) >> 16;
            C_Size = ((result[1] & 0x000003fful) << 2) | ((result[2] & 0xc0000000ul) >> 30);
            MULT = (result[2] & 0x00038000ul) >> 15;
            size = (C_Size+1ul) * (1ul<<(MULT+2ul)) * (1ul<<R_LEN);

            SDInfo.diskSize = size / 1024ul;
            SDInfo.totalSectorN = size / 512ul;
        }
				
	//�趨SDʱ�� 24M
	SYS_UnlockReg();
  CLK_EnableModuleClock(SDH0_MODULE);//ʹ��UART0 ʱ��
  CLK_SetModuleClock(SDH0_MODULE, CLK_CLKSEL0_SDH0SEL_HCLK, CLK_CLKDIV0_SDH0(4));//SD0 ʱ�� HIRC/32 = 12MHz/32=375K SYS_LockReg();
  SYS_ResetModule(SDH0_RST);
	SYS_LockReg();
			

		
}
void sdsendcmd(uint32_t cmd)
{

	uint32_t buf = (SDH0->CTL&(~SDH_CTL_CMDCODE_Msk))|(cmd << 8ul)|(SDH_CTL_COEN_Msk);
	SDH0->CTL=buf;
	while ((SDH0->CTL & SDH_CTL_COEN_Msk) == SDH_CTL_COEN_Msk);
}
uint32_t sendcmdandread(uint32_t cmd,uint32_t arg,uint32_t needack)
{
	uint32_t buf ;
	uint32_t ret;
	uint32_t tmp0 = 0ul, tmp1= 0ul;
	SDH0->CMDARG = arg;
	buf= (SDH0->CTL & (~SDH_CTL_CMDCODE_Msk)) | (cmd << 8ul) | (SDH_CTL_COEN_Msk );
	if(needack)
	{
		buf |= SDH_CTL_RIEN_Msk;
	}
	SDH0->CTL=buf;
	if(needack)
	{
		while ((SDH0->CTL & SDH_CTL_RIEN_Msk) == SDH_CTL_RIEN_Msk) {}   
    tmp1 = SDH0->RESP1 & 0xfful;
    tmp0 = SDH0->RESP0 & 0xful;
	}
	return ret;
}
//void readdata(uint32_t sector,uint8_t* buffer,uint32_t count)
//{
//	uint32_t rca,reg;
//	
//	sendcmdandread(3ul, 0x00ul,1);


//	rca=(SDH0->RESP0 << 8) & 0xffff0000;
//	sendcmdandread(7ul,rca,0);	
//	while(1)
//  {
//    SDH0->CTL |= SDH_CTL_CLK8OEN_Msk;
//    while ((SDH0->CTL & SDH_CTL_CLK8OEN_Msk) == SDH_CTL_CLK8OEN_Msk)
//    {}
//    if ((SDH0->INTSTS & SDH_INTSTS_DAT0STS_Msk) == SDH_INTSTS_DAT0STS_Msk)
//    {
//      break;
//    }
//  }	
//	SDH0->BLEN=511;
//	SDH0->CMDARG = sector;
//	SDH0->DMASA = (uint32_t)buffer;
//	reg = SDH0->CTL & ~SDH_CTL_CMDCODE_Msk;
//  reg = reg | 0xff0000ul;   /* set BLK_CNT to 255 */
//  SDH0->CTL = reg|(18ul << 8)|(SDH_CTL_COEN_Msk | SDH_CTL_RIEN_Msk | SDH_CTL_DIEN_Msk);
//	while(!(SDH0->INTSTS & SDH_INTSTS_BLKDIF_Msk)){};
//	
//}
int main(void)
{
	uint8_t readbuf[1024]={0};
 DEV_InitBoard();
 TC_TaskInit();
 DebugInit();
 AppProtocolControllerInit();
 TestInit();
sdinit();
//	sdsendcmd(0);
//	sendcmdandread(8ul,0x00000155ul);
//	readdata(0,readbuf,512);
//	while(1){}
	 SYS_UnlockReg();
 CLK_EnableModuleClock(SDH0_MODULE);//ʹ��UART0 ʱ��
 CLK_SetModuleClock(SDH0_MODULE, CLK_CLKSEL0_SDH0SEL_PLL, CLK_CLKDIV0_SDH0(10));//SD0 ʱ�� HIRC/32 = 12MHz/32=375K
 
 SYS->GPB_MFPL &= ~(SYS_GPB_MFPL_PB4MFP_Msk | SYS_GPB_MFPL_PB5MFP_Msk);
 SYS->GPB_MFPL |= (SYS_GPB_MFPL_PB4MFP_SD0_DAT2 | SYS_GPB_MFPL_PB5MFP_SD0_DAT3);

 SYS->GPE_MFPL &= ~(SYS_GPE_MFPL_PE2MFP_Msk | SYS_GPE_MFPL_PE3MFP_Msk | SYS_GPE_MFPL_PE6MFP_Msk | SYS_GPE_MFPL_PE7MFP_Msk);
 SYS->GPE_MFPL |= (SYS_GPE_MFPL_PE2MFP_SD0_DAT0 | SYS_GPE_MFPL_PE3MFP_SD0_DAT1 | SYS_GPE_MFPL_PE6MFP_SD0_CLK | SYS_GPE_MFPL_PE7MFP_SD0_CMD);
	
 SYS->GPD_MFPH &= ~(SYS_GPD_MFPH_PD13MFP_Msk);
 SYS->GPD_MFPH |= (SYS_GPD_MFPH_PD13MFP_SD0_nCD );
	
 SYS_LockReg();
 SYS_ResetModule(SDH0_RST); 
 
	SDH_Open(SDH0,CardDetect_From_GPIO);
	SDH_Probe(SDH0);
	
	SDH_Read(SDH0,readbuf,0,1);
	//SDH_Read(SDH0,&readbuf[128],0,128);
	while(1);
 while(1)
 {
	TC_TaskRun();
 }
}
void SDH0_IRQHandler(void)
{
    unsigned int volatile isr;
    unsigned int volatile ier;

    // FMI data abort interrupt
    if (SDH0->GINTSTS & SDH_GINTSTS_DTAIF_Msk)
    {
        /* ResetAllEngine() */
        SDH0->GCTL |= SDH_GCTL_GCTLRST_Msk;
    }

    //----- SD interrupt status
    isr = SDH0->INTSTS;
    if (isr & SDH_INTSTS_BLKDIF_Msk)
    {
        // block down
        g_u8SDDataReadyFlag = TRUE;
        SDH0->INTSTS = SDH_INTSTS_BLKDIF_Msk;
    }

    if (isr & SDH_INTSTS_CDIF_Msk)   // card detect
    {
        //----- SD interrupt status
        // it is work to delay 50 times for SD_CLK = 200KHz
        {
            int volatile i;         // delay 30 fail, 50 OK
            for (i=0; i<0x500; i++);  // delay to make sure got updated value from REG_SDISR.
            isr = SDH0->INTSTS;
        }

        if (isr & SDH_INTSTS_CDSTS_Msk)
        {
            //printf("\n***** card remove !\n");
            SD0.IsCardInsert = FALSE;   // SDISR_CD_Card = 1 means card remove for GPIO mode
            memset(&SD0, 0, sizeof(SDH_INFO_T));
        }
        else
        {
            //printf("***** card insert !\n");
            //gSdInit = 1;
           //SDH_Open(SDH0, CardDetect_From_GPIO);
           // SDH_Probe(SDH0);
        }

        SDH0->INTSTS = SDH_INTSTS_CDIF_Msk;
    }

    // CRC error interrupt
    if (isr & SDH_INTSTS_CRCIF_Msk)
    {
        if (!(isr & SDH_INTSTS_CRC16_Msk))
        {
            //printf("***** ISR sdioIntHandler(): CRC_16 error !\n");
            // handle CRC error
        }
        else if (!(isr & SDH_INTSTS_CRC7_Msk))
        {
            if (!g_u8R3Flag)
            {
                //printf("***** ISR sdioIntHandler(): CRC_7 error !\n");
                // handle CRC error
            }
        }
        SDH0->INTSTS = SDH_INTSTS_CRCIF_Msk;      // clear interrupt flag
    }

    if (isr & SDH_INTSTS_DITOIF_Msk)
    {
        //printf("***** ISR: data in timeout !\n");
        SDH0->INTSTS |= SDH_INTSTS_DITOIF_Msk;
    }

    // Response in timeout interrupt
    if (isr & SDH_INTSTS_RTOIF_Msk)
    {
        //printf("***** ISR: response in timeout !\n");
        SDH0->INTSTS |= SDH_INTSTS_RTOIF_Msk;
    }
}