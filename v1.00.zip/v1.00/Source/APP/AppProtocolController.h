#ifndef AppProtocolController_H
#define AppProtocolController_H
#include "../TCSYS_Config.h"
#include "../Device/DEV.h"
#include "../Common/Queue.h"
#include "../Common/FIFO.h"
typedef struct
{
	SByte* APPName;
	SByte* ProtocolName;
  TC_QueueStruct* ReceiveQueue;
	TC_QueueStruct* SendQueue;
	void* TaskParam;
	void (*ProtocolTask)(void* TaskParam,UInt32 TimeInterval);
}AppProtocolQueueStruct;
Bool AppProtocolRegeist(const DevNodeStruct* DEV,const AppProtocolQueueStruct* AppQueue);
void AppProtocolControllerInit(void);
#endif
