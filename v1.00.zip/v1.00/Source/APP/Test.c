#include "../TCSYS_Config.h"
#include "../Task/TC_Task.h"
#include "../Device/DEV.h"
#include "../Device/DEV_UART4.h"
#include "Debug.h"
#include <stdlib.h>
#include <string.h>

#include "AppProtocolController.h"
#include "Modbus.h"
const char* TestTaskName1="TestTask1";
static TaskIDType TestTask1ID=TaskIDNone;
const char* TestTaskName2="TestTask2";
static TaskIDType TestTask2ID=TaskIDNone;

void TestTask1(void* TaskParam,void *TaskInfo)
{
	static UInt16 time=0;
	SByte buf[20];
	int ret=sprintf((SByte*)buf,"%s:%d\n","TestTask1",time);
	time++;
  //DebugOut(buf,ret,TC_TRUE);
	//DEV_Write(&DEVNode_UART4,TestTask1ID,buf,ret);
	TC_TaskSetTimeBlock(TaskInfo,TaskTimeS(1));
}
void TestTask2(void* TaskParam,void *TaskInfo)
{
	static UInt16 time=0;
	SByte buf[20];
	int ret=sprintf((SByte*)buf,"%s:%d\n","TestTask2",time);
	time++;
  //DebugOut(buf,ret,TC_TRUE);
	TC_TaskSetTimeBlock(TaskInfo,TaskTimeMs(1500));
}

static const SByte *PTestCMD=(void*)"TestCMD";

void TestCMDDo(Byte* Param)
{
	SByte SendBuf[100];
	sprintf(SendBuf,"%s---%s\n","PTest",Param);
	DebugOut(SendBuf,strlen(SendBuf),TC_TRUE);
	
  free(Param);
}

 ProtocolModbusMuStruct TestModbusMu;
 ProtocolModbusMuStruct TestModbusMu2;
static AppProtocolQueueStruct TestProtocolQueue;
static AppProtocolQueueStruct TestProtocolQueue2;
void TestInit()
{
	DebugCmdParamStruct CMDReg;
	CMDReg.CMD=(void*)PTestCMD;
	CMDReg.CMDLength=strlen(CMDReg.CMD);
	CMDReg.Callback=TestCMDDo;
	

	
	DebugRegistCmd(&CMDReg);
	TestTask1ID=TC_Task_Add(TestTask1,TestTaskName1);

	DBModbusInit();
	TestModbusMu.Param.Addr=0x01;
	TestModbusMu.Param.FrameType=DBModbusDataTypeEnum_RTU;
	TestModbusMu.Param.ReceiveTimeOutMax=TaskTimeMs(5);
	ModbusInit(&TestModbusMu);
	
	TestProtocolQueue.APPName="Test";
	TestProtocolQueue.ProtocolName="ModbusRTU";
	TestProtocolQueue.ReceiveQueue=&TestModbusMu.ReceiveQueue;
	TestProtocolQueue.SendQueue=&TestModbusMu.SendQueue;
	TestProtocolQueue.TaskParam=&TestModbusMu;
	TestProtocolQueue.ProtocolTask=ModbusTask;
	
	TestModbusMu2.Param.Addr=0x02;
	TestModbusMu2.Param.FrameType=DBModbusDataTypeEnum_RTU;
	TestModbusMu2.Param.ReceiveTimeOutMax=TaskTimeMs(5);
	ModbusInit(&TestModbusMu2);
	
	TestProtocolQueue2.APPName="Test2";
	TestProtocolQueue2.ProtocolName="ModbusRTU";
	TestProtocolQueue2.ReceiveQueue=&TestModbusMu2.ReceiveQueue;
	TestProtocolQueue2.SendQueue=&TestModbusMu2.SendQueue;
	TestProtocolQueue2.TaskParam=&TestModbusMu2;
	TestProtocolQueue2.ProtocolTask=ModbusTask;
	
 
	AppProtocolRegeist(&DEVNode_UART4,&TestProtocolQueue);
	AppProtocolRegeist(&DEVNode_UART4,&TestProtocolQueue2);
	//TC_Task_Add(TestTask2,TestTaskName2);
}

