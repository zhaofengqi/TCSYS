#include "../TCSYS_Config.h"
#include <stdlib.h>
#include <string.h>
#include "../Device/DEV.h"
#include "../Device/DEV_DebugIO.h"
#include "../Task/TC_Task.h"
#include "Debug.h"
#include "../Common/Queue.h"
#define DebugMsgMaxCount 50
const char* DebugTaskName="DebugTask";
typedef struct
{
	SByte *Msg;
	UInt16 MsgLength;
	Byte MsgNeedFree;
}DebugMsgStruct;

typedef struct
{
	DebugMsgStruct MsgBUF[DebugMsgMaxCount];
	UInt16 MsgCount;
	UInt16 MsgWritePtr;
	UInt16 MsgReadPtr;
	UInt16 SendPtr;
}DebugMsgMuStruct;


#define DebugReceiveBufMax 500
Byte DebugReceiveBuf[DebugReceiveBufMax];

TC_QueueStruct DebugReceiveQueue;
DebugCmdListStruct DebugCmdList;
DebugMsgMuStruct DebugMsgMu;
TaskIDType DebugTaskID=TaskIDNone;

void DebugOut(SByte* Data, UInt16 Length,Bool NeedFree)
{
	SByte* msgmem;
  if(DebugMsgMu.MsgCount<DebugMsgMaxCount)
	{
		CriticalIn;

			if(NeedFree)
			{
				msgmem=malloc(Length);
				if(msgmem!=NULL)
				{
					memcpy(msgmem,Data,Length);
				}
				else
				{
					while(1);
				}
			}
			else
			{
				msgmem=Data;
			}
			if(msgmem!=NULL)
			{
				
				DebugMsgMu.MsgBUF[DebugMsgMu.MsgWritePtr].Msg=msgmem;
				DebugMsgMu.MsgBUF[DebugMsgMu.MsgWritePtr].MsgLength=Length;
				DebugMsgMu.MsgBUF[DebugMsgMu.MsgWritePtr].MsgNeedFree=NeedFree;
				DebugMsgMu.MsgWritePtr++;
				if(DebugMsgMu.MsgWritePtr>=DebugMsgMaxCount)
				{
					DebugMsgMu.MsgWritePtr=0;
				}
				DebugMsgMu.MsgCount++;	 
			}
		CriticalOut;
	}
}

Bool DebugRegistCmd(DebugCmdParamStruct * DebugCmdParam)
{
  if(DebugCmdList.Count<DebugIOCmdMax)
	{
		DebugCmdList.CmdList[DebugCmdList.Count]=*DebugCmdParam;
		DebugCmdList.Count++;
		return TC_TRUE;
	}
	return TC_FALSE;
}

Bool DebugDeregistCmd(DebugCmdParamStruct * DebugCmdParam)
{
	UInt16 i;
	for(i=0;i<DebugCmdList.Count;i++)
	{
		if(strcasecmp(DebugCmdList.CmdList[i].CMD,DebugCmdParam->CMD)==0)
		{
			while(i<DebugCmdList.Count-1)
			{
				DebugCmdList.CmdList[i]=DebugCmdList.CmdList[i+1];
			}
			DebugCmdList.Count--;
			return TC_TRUE;
		}
	}
	return TC_FALSE;
}

static inline void DebugReceiveHandle(void)
{
	static UInt16 CheckPtr=0;
	UInt16 CmpStartPtr=0;
	UInt16 CMDListPtr=0,CMDParamLength=0,DMDParamPtr;
	Byte* Param=NULL;
	if(DebugReceiveQueue.WritePtr==0)
	{
		return;
	}
	for(;CheckPtr<DebugReceiveQueue.WritePtr-1;CheckPtr++)
	{
		if((DebugReceiveBuf[CheckPtr]=='\r')&&(DebugReceiveBuf[CheckPtr+1]=='\n'))
		{
			DebugReceiveBuf[CheckPtr+1]=0;
			for(;CmpStartPtr<CheckPtr;CmpStartPtr++)
			{
				if(DebugReceiveBuf[CmpStartPtr]!=' ')
				{
					CMDParamLength=CheckPtr-(CmpStartPtr+DebugCmdList.CmdList[CMDListPtr].CMDLength)+1;
					DMDParamPtr=CmpStartPtr+DebugCmdList.CmdList[CMDListPtr].CMDLength+1;
					for(CMDListPtr=0;CMDListPtr<DebugCmdList.Count;CMDListPtr++)
					{
						if(!strncmp(DebugCmdList.CmdList[CMDListPtr].CMD,(void*)&DebugReceiveBuf[CmpStartPtr],DebugCmdList.CmdList[CMDListPtr].CMDLength))
						{
							if(DebugReceiveBuf[DMDParamPtr-1]==' ')
							{
								CMDParamLength--;
								Param=malloc(CMDParamLength);
								if(Param!=NULL)
								{
									memcpy(Param,&DebugReceiveBuf[DMDParamPtr],CMDParamLength);
									Param[CMDParamLength-1]=0;
								}
								DebugCmdList.CmdList[CMDListPtr].Callback(Param);					
							}
						}
					}
					break;
				}
			}
			memcpy(DebugReceiveBuf,&DebugReceiveBuf[CheckPtr+2],DebugReceiveQueue.WritePtr-CheckPtr-2);
			DebugReceiveQueue.WritePtr=DebugReceiveQueue.WritePtr-CheckPtr-2;
			CheckPtr=0;
			break;
		}
		if(DebugReceiveQueue.WritePtr==0)
		{
			break;
		}
	}
	if(DebugReceiveQueue.WritePtr>=DebugReceiveBufMax)
	{
		CheckPtr=0;
		DebugReceiveQueue.WritePtr=0;
	}
}
static void Task(void* TaskParam,void *TaskInfo)
{
	UInt16 unreadcount=0,unwritecount=0,writeoversize=0;
	DebugMsgStruct *currentmsg=NULL;
 
	DEV_IOControl(&DEVNode_DebugIO,DebugTaskID,DevCMD_GetUnreadCount,NULL,&unreadcount);
 
	DEV_IOControl(&DEVNode_DebugIO,DebugTaskID,DevCMD_GetUnwriteCount,NULL,&unwritecount);
	if(unreadcount>0)
	{
		if(unreadcount>(DebugReceiveQueue.Size-DebugReceiveQueue.WritePtr))
		{
			unreadcount=DebugReceiveQueue.Size-DebugReceiveQueue.WritePtr;
		}
		DebugReceiveQueue.WritePtr+= DEV_Read(&DEVNode_DebugIO,DebugTaskID,&DebugReceiveBuf[DebugReceiveQueue.WritePtr],unreadcount);
		
	}
	DebugReceiveHandle();
	if((unwritecount>0)&&(DebugMsgMu.MsgCount>0))
	{
		currentmsg=&DebugMsgMu.MsgBUF[DebugMsgMu.MsgReadPtr];
		writeoversize = DEV_Write(&DEVNode_DebugIO,DebugTaskID,&currentmsg->Msg[DebugMsgMu.SendPtr],currentmsg->MsgLength-DebugMsgMu.SendPtr);
		DebugMsgMu.SendPtr+=writeoversize;
		if(DebugMsgMu.SendPtr>=currentmsg->MsgLength)
		{
			DebugMsgMu.SendPtr=0;
			if(currentmsg->MsgNeedFree==1)
			{
				free(currentmsg->Msg);
			}
			DebugMsgMu.MsgReadPtr++;
			if(DebugMsgMu.MsgReadPtr>=DebugMsgMaxCount)
			{
				DebugMsgMu.MsgReadPtr=0;
			}
			DebugMsgMu.MsgCount--;
		}
	}
	//TC_TaskSetTimeBlock(TaskInfo,TaskTimeMs(3000));
}
void DebugInit(void)
{
  DebugReceiveQueue.Size=DebugReceiveBufMax;
	DebugReceiveQueue.WritePtr=0;
  DebugReceiveQueue.Memory=DebugReceiveBuf;
	DebugTaskID=TC_Task_Add(Task,DebugTaskName);
	DEV_Init((DevNodeStruct*)&DEVNode_DebugIO);
	DEV_Open(&DEVNode_DebugIO,DebugTaskID);
}
