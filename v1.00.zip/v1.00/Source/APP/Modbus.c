#include "AppProtocolController.h"
#include "DataBase/DB_Modbus.h"
#include "Modbus.h"

static const UInt16 CRC16Table[] = {
0x0000, 0xC0C1, 0xC181, 0x0140, 0xC301, 0x03C0, 0x0280, 0xC241,
0xC601, 0x06C0, 0x0780, 0xC741, 0x0500, 0xC5C1, 0xC481, 0x0440,
0xCC01, 0x0CC0, 0x0D80, 0xCD41, 0x0F00, 0xCFC1, 0xCE81, 0x0E40,
0x0A00, 0xCAC1, 0xCB81, 0x0B40, 0xC901, 0x09C0, 0x0880, 0xC841,
0xD801, 0x18C0, 0x1980, 0xD941, 0x1B00, 0xDBC1, 0xDA81, 0x1A40,
0x1E00, 0xDEC1, 0xDF81, 0x1F40, 0xDD01, 0x1DC0, 0x1C80, 0xDC41,
0x1400, 0xD4C1, 0xD581, 0x1540, 0xD701, 0x17C0, 0x1680, 0xD641,
0xD201, 0x12C0, 0x1380, 0xD341, 0x1100, 0xD1C1, 0xD081, 0x1040,
0xF001, 0x30C0, 0x3180, 0xF141, 0x3300, 0xF3C1, 0xF281, 0x3240,
0x3600, 0xF6C1, 0xF781, 0x3740, 0xF501, 0x35C0, 0x3480, 0xF441,
0x3C00, 0xFCC1, 0xFD81, 0x3D40, 0xFF01, 0x3FC0, 0x3E80, 0xFE41,
0xFA01, 0x3AC0, 0x3B80, 0xFB41, 0x3900, 0xF9C1, 0xF881, 0x3840,
0x2800, 0xE8C1, 0xE981, 0x2940, 0xEB01, 0x2BC0, 0x2A80, 0xEA41,
0xEE01, 0x2EC0, 0x2F80, 0xEF41, 0x2D00, 0xEDC1, 0xEC81, 0x2C40,
0xE401, 0x24C0, 0x2580, 0xE541, 0x2700, 0xE7C1, 0xE681, 0x2640,
0x2200, 0xE2C1, 0xE381, 0x2340, 0xE101, 0x21C0, 0x2080, 0xE041,
0xA001, 0x60C0, 0x6180, 0xA141, 0x6300, 0xA3C1, 0xA281, 0x6240,
0x6600, 0xA6C1, 0xA781, 0x6740, 0xA501, 0x65C0, 0x6480, 0xA441,
0x6C00, 0xACC1, 0xAD81, 0x6D40, 0xAF01, 0x6FC0, 0x6E80, 0xAE41,
0xAA01, 0x6AC0, 0x6B80, 0xAB41, 0x6900, 0xA9C1, 0xA881, 0x6840,
0x7800, 0xB8C1, 0xB981, 0x7940, 0xBB01, 0x7BC0, 0x7A80, 0xBA41,
0xBE01, 0x7EC0, 0x7F80, 0xBF41, 0x7D00, 0xBDC1, 0xBC81, 0x7C40,
0xB401, 0x74C0, 0x7580, 0xB541, 0x7700, 0xB7C1, 0xB681, 0x7640,
0x7200, 0xB2C1, 0xB381, 0x7340, 0xB101, 0x71C0, 0x7080, 0xB041,
0x5000, 0x90C1, 0x9181, 0x5140, 0x9301, 0x53C0, 0x5280, 0x9241,
0x9601, 0x56C0, 0x5780, 0x9741, 0x5500, 0x95C1, 0x9481, 0x5440,
0x9C01, 0x5CC0, 0x5D80, 0x9D41, 0x5F00, 0x9FC1, 0x9E81, 0x5E40, 
0x5A00, 0x9AC1, 0x9B81, 0x5B40, 0x9901, 0x59C0, 0x5880, 0x9841,
0x8801, 0x48C0, 0x4980, 0x8941, 0x4B00, 0x8BC1, 0x8A81, 0x4A40,
0x4E00, 0x8EC1, 0x8F81, 0x4F40, 0x8D01, 0x4DC0, 0x4C80, 0x8C41,
0x4400, 0x84C1, 0x8581, 0x4540, 0x8701, 0x47C0, 0x4680, 0x8641,
0x8201, 0x42C0, 0x4380, 0x8341, 0x4100, 0x81C1, 0x8081, 0x4040
};

static UInt16 ModBusCRC(uint8_t* Data, UInt16 DataLength)
{  
  UInt16 Result  = 0xFFFF;
 
  for(int i = 0; i < DataLength; i++)
  {
      Result  = ((Result >> 8)) ^ CRC16Table[(Result^Data[i])& 0xff];
  } 
  return Result;
}
static inline UInt16 ModbusGetUInt16(Byte* Data)
{
	UInt16 Ret=Data[0];
	Ret<<=8;
	Ret+=Data[1];
}
void ModbusInit(ProtocolModbusMuStruct *PModbusMu)
{
	PModbusMu->SendQueue.Memory=PModbusMu->SendBuf;
	PModbusMu->SendQueue.Size=ModbusBufMax;
	PModbusMu->SendQueue.WritePtr=0;
	
	PModbusMu->ReceiveQueue.Memory=PModbusMu->ReceiveBuf;
	PModbusMu->ReceiveQueue.Size=ModbusBufMax;
	PModbusMu->ReceiveQueue.WritePtr=0;
	
	PModbusMu->PMu.CurrentFunc=ModbusFuncEnum_None;
}
 
void ModbufFrameHandle(ProtocolModbusMuStruct* PModbusMu)
{
	Byte* RecvBuf=PModbusMu->ReceiveBuf;
	Byte* SendBuf=PModbusMu->SendBuf;
  UInt16 ReadRetCount,FrameCRC=0;
	UInt16 SendPtr=0;
	DBModbusErrorEnum ErrorRet=DBModbusErrorEnum_00;
	if(PModbusMu->Param.FrameType==DBModbusDataTypeEnum_RTU)
	{
		if(PModbusMu->PMu.ExpectFrameLength==0)
		{
			if(PModbusMu->ReceiveQueue.WritePtr>=2)
			{
				PModbusMu->PMu.CurrentFunc=RecvBuf[1];
				switch(PModbusMu->PMu.CurrentFunc)
				{
					case ModbusFuncEnum_None:
					break;
					case ModbusFuncEnum_ReadCircle:
					case ModbusFuncEnum_ReadInputBinSignal:
					case ModbusFuncEnum_ReadInsideReg:
					case ModbusFuncEnum_ReadInputReg:
							if(PModbusMu->ReceiveQueue.WritePtr>=6)
							{
								PModbusMu->PMu.ReadRegAddr=ModbusGetUInt16(&RecvBuf[2]);
								PModbusMu->PMu.ReadCount=ModbusGetUInt16(&RecvBuf[4]);
								PModbusMu->PMu.ExpectFrameLength=8;
							}
					break;
					case ModbusFuncEnum_WriteCircle:
					case ModbusFuncEnum_WriteSingleReg:
						  if(PModbusMu->ReceiveQueue.WritePtr>=6)
							{
								PModbusMu->PMu.WriteRegAddr=ModbusGetUInt16(&RecvBuf[2]);
								PModbusMu->PMu.WriteCount=ModbusGetUInt16(&RecvBuf[4]);
								PModbusMu->PMu.ExpectFrameLength=8;
							}
					break;	
					case ModbusFuncEnum_WriteMutiCircle:
					  if(PModbusMu->ReceiveQueue.WritePtr>=7)
						{
							PModbusMu->PMu.WriteRegAddr=ModbusGetUInt16(&RecvBuf[2]);
							PModbusMu->PMu.WriteCount=ModbusGetUInt16(&RecvBuf[4]);
							PModbusMu->PMu.WriteBytes=RecvBuf[6];
							PModbusMu->PMu.ExpectFrameLength=9+(PModbusMu->PMu.WriteCount>>3);
							
							if(PModbusMu->PMu.WriteCount&0x7)
							{
								PModbusMu->PMu.ExpectFrameLength++;
							}
						}
					break;		
					case ModbusFuncEnum_WriteMutiReg:
						if(PModbusMu->ReceiveQueue.WritePtr>=7)
						{
							PModbusMu->PMu.WriteRegAddr=ModbusGetUInt16(&RecvBuf[2]);
							PModbusMu->PMu.WriteCount=ModbusGetUInt16(&RecvBuf[4]);
							PModbusMu->PMu.WriteBytes=RecvBuf[6];
							PModbusMu->PMu.ExpectFrameLength=8+(PModbusMu->PMu.WriteCount<<1);
						}
					break;
					case ModbusFuncEnum_ReadWriteMutiReg:
						if(PModbusMu->ReceiveQueue.WritePtr>=13)
						{
						  PModbusMu->PMu.ReadRegAddr=ModbusGetUInt16(&RecvBuf[2]);
							PModbusMu->PMu.ReadCount=ModbusGetUInt16(&RecvBuf[4]);
							PModbusMu->PMu.WriteRegAddr=ModbusGetUInt16(&RecvBuf[6]);
							PModbusMu->PMu.WriteCount=ModbusGetUInt16(&RecvBuf[8]);
							PModbusMu->PMu.WriteBytes=RecvBuf[10];
							PModbusMu->PMu.ExpectFrameLength=13+(PModbusMu->PMu.WriteCount<<1);
						}
					break;
					default:
						TC_QueueScoll(&PModbusMu->ReceiveQueue,1,TC_FALSE);
						PModbusMu->PMu.ReceiveTimeOutTimer=0;
					break;
				}
			}
		}
	  if((PModbusMu->ReceiveQueue.WritePtr>=PModbusMu->PMu.ExpectFrameLength)&&(PModbusMu->PMu.ExpectFrameLength>2))
		{
				FrameCRC=ModBusCRC(RecvBuf,PModbusMu->PMu.ExpectFrameLength-2);
			  if(
						((FrameCRC&0xFF)==RecvBuf[PModbusMu->PMu.ExpectFrameLength-2])&&
						((FrameCRC>>8)==RecvBuf[PModbusMu->PMu.ExpectFrameLength-1])					
				)
				{
					if(RecvBuf[0]==PModbusMu->Param.Addr)
					{
						switch(RecvBuf[1])
						{
							case ModbusFuncEnum_ReadCircle:
							case ModbusFuncEnum_ReadInputBinSignal:
							case ModbusFuncEnum_ReadInsideReg:
							case ModbusFuncEnum_ReadInputReg:
								ErrorRet=DBModbusInterface.ReadData(PModbusMu->PMu.CurrentFunc,PModbusMu->PMu.ReadRegAddr,PModbusMu->PMu.ReadCount,&SendBuf[3],&ReadRetCount,PModbusMu->Param.FrameType);
								SendBuf[0]=PModbusMu->Param.Addr;
								SendBuf[1]=PModbusMu->PMu.CurrentFunc;
								SendBuf[2]=ReadRetCount;
								SendPtr=ReadRetCount+5;
							break;
							case ModbusFuncEnum_WriteCircle:
							case ModbusFuncEnum_WriteSingleReg:
							case ModbusFuncEnum_WriteMutiCircle:
							case ModbusFuncEnum_WriteMutiReg:
								ErrorRet=DBModbusInterface.WriteData(PModbusMu->PMu.CurrentFunc,PModbusMu->PMu.WriteRegAddr,PModbusMu->PMu.WriteCount,&RecvBuf[7],PModbusMu->Param.FrameType);							
								SendBuf[2]=RecvBuf[2];
								SendBuf[3]=RecvBuf[3];
								SendBuf[4]=RecvBuf[4];
								SendBuf[5]=RecvBuf[5];
								SendPtr=ReadRetCount+8;
							break;
							case ModbusFuncEnum_ReadWriteMutiReg:

								ErrorRet=DBModbusInterface.ReadData(PModbusMu->PMu.CurrentFunc,PModbusMu->PMu.ReadRegAddr,PModbusMu->PMu.ReadCount,&SendBuf[3],&ReadRetCount,PModbusMu->Param.FrameType);
								if(ErrorRet==DBModbusErrorEnum_00)
								{
									ErrorRet=DBModbusInterface.WriteData(PModbusMu->PMu.CurrentFunc,PModbusMu->PMu.WriteRegAddr,PModbusMu->PMu.WriteCount,&RecvBuf[7],PModbusMu->Param.FrameType);
								}							
								SendBuf[0]=PModbusMu->Param.Addr;
								SendBuf[1]=PModbusMu->PMu.CurrentFunc;
								SendBuf[2]=ReadRetCount;
								SendPtr=ReadRetCount+5;
							break;
							default:
							break;
						}
						if(ErrorRet!=DBModbusErrorEnum_00)
						{
							SendBuf[0]=PModbusMu->Param.Addr;
							SendBuf[1]=PModbusMu->PMu.CurrentFunc|0x80;
							SendBuf[2]=ErrorRet;
							SendPtr=5;
						}
						FrameCRC=ModBusCRC(SendBuf,SendPtr-2);
						SendBuf[SendPtr-2]=FrameCRC&0xff;
						SendBuf[SendPtr-1]=FrameCRC>>8;
						PModbusMu->SendQueue.WritePtr=SendPtr;
					}	
					TC_QueueScoll(&PModbusMu->ReceiveQueue,PModbusMu->PMu.ExpectFrameLength,TC_FALSE);				
					PModbusMu->PMu.CurrentFunc=ModbusFuncEnum_None;
					PModbusMu->PMu.ExpectFrameLength=0;
					PModbusMu->PMu.ReceiveTimeOutTimer=0;
				}
				else
				{
					TC_QueueScoll(&PModbusMu->ReceiveQueue,1,TC_FALSE);
					PModbusMu->PMu.CurrentFunc=ModbusFuncEnum_None;
					PModbusMu->PMu.ExpectFrameLength=0;
					PModbusMu->PMu.ReceiveTimeOutTimer=0;
				}
			}
	}
	else if(PModbusMu->Param.FrameType==DBModbusDataTypeEnum_ASCII)
	{
	
	}
 
}
void ModbusTask(void* Param,UInt32 TimeInterval)
{
	ProtocolModbusMuStruct* PModbusMu=(ProtocolModbusMuStruct* )Param;
	if(PModbusMu->SendQueue.WritePtr==0)
	{
		if(PModbusMu->ReceiveQueue.WritePtr>0)
		{	
			ModbufFrameHandle(PModbusMu);	
			if(PModbusMu->ReceiveQueue.WritePtr!=PModbusMu->PMu.LastRecvQueueWritePtr)
			{		
				PModbusMu->PMu.ReceiveTimeOutTimer=0;	
				PModbusMu->PMu.LastRecvQueueWritePtr=PModbusMu->ReceiveQueue.WritePtr;				
			}
			else
			{
				PModbusMu->PMu.ReceiveTimeOutTimer+=TimeInterval;
				if(PModbusMu->PMu.ReceiveTimeOutTimer>PModbusMu->Param.ReceiveTimeOutMax)
				{
					PModbusMu->PMu.ReceiveTimeOutTimer=0;
					PModbusMu->PMu.LastRecvQueueWritePtr=0;
					TC_QueueScoll(&PModbusMu->ReceiveQueue,1,TC_FALSE);
					PModbusMu->PMu.CurrentFunc=ModbusFuncEnum_None;
					PModbusMu->PMu.ExpectFrameLength=0;
				}
			}
		}
	}
}
