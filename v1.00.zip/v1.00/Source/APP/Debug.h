#ifndef Debug_H
#define Debug_H
#include "../TCSYS_Config.h"
typedef struct
{
	SByte* CMD;
	UInt16 CMDLength;
	void (*Callback)(Byte* Param);
}DebugCmdParamStruct;

#define DebugIOCmdMax 20
typedef struct
{
	DebugCmdParamStruct CmdList[DebugIOCmdMax];
  UInt16 Count;
}DebugCmdListStruct;

void DebugInit(void);
void DebugOut(SByte* Data, UInt16 Length,Bool NeedFree);
Bool DebugRegistCmd(DebugCmdParamStruct * DebugCmdParam);
Bool DebugDeregistCmd(DebugCmdParamStruct * DebugCmdParam);
#endif

