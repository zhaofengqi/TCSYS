#ifndef Modbus_H
#define Modbus_H
#include "../TCSYS_Config.h"
#include "../Common/Queue.h"
#include "DataBase/DB_Modbus.h"
typedef struct
{
	Byte Addr;
	DBModbusDataTypeEnum FrameType;
	UInt32 ReceiveTimeOutMax;
}ModbusParamStruct;
typedef enum
{
	ModbusFuncEnum_None=0x00,
	ModbusFuncEnum_ReadCircle=0x01,
	ModbusFuncEnum_ReadInputBinSignal=0x02,
	ModbusFuncEnum_ReadInsideReg=0x03,
	ModbusFuncEnum_ReadInputReg=0x04,
	ModbusFuncEnum_WriteCircle=0x05,
	ModbusFuncEnum_WriteSingleReg=0x06,
	ModbusFuncEnum_WriteMutiCircle=0x0f,
	ModbusFuncEnum_WriteMutiReg=0x10,
	ModbusFuncEnum_ReadWriteMutiReg=0x17,
}ModbusFuncEnum;
 
typedef enum
{
	ModbusErrorEnum_Func=0x01,
	ModbusErrorEnum_Addr=0x02,
	ModbusErrorEnum_Data=0x03,
}ModbusErrorEnum;

typedef struct
{
	ModbusFuncEnum CurrentFunc;
	UInt16 ReadRegAddr;
	UInt16 WriteRegAddr;
	UInt16 ReadCount;
	UInt16 WriteCount;
	Byte WriteBytes;
	UInt16 ExpectFrameLength;
	UInt16 LastRecvQueueWritePtr;
	UInt32 ReceiveTimeOutTimer;
}ModbusProcessMuStruct;

#define ModbusBufMax 512
typedef struct
{
	Byte ReceiveBuf[ModbusBufMax];
	Byte SendBuf[ModbusBufMax];
	TC_QueueStruct ReceiveQueue;
	TC_QueueStruct SendQueue;
	ModbusParamStruct Param;
	ModbusProcessMuStruct PMu;
}ProtocolModbusMuStruct;
void ModbusTask(void* Param,UInt32 TimeInterval);
void ModbusInit(ProtocolModbusMuStruct *PModbusMu);
#endif
