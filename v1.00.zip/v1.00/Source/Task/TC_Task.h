#ifndef TC_Task_H
#define TC_Task_H
#include "../TCSYS_Config.h"
#include "../Common/Lock.h"

#define TaskCountMax 20
typedef enum
{
	 TaskStateEnum_Ready,
	 TaskStateEnum_TimeBlock,
	 TaskStateEnum_MutexBlock,
}TaskStateEnum;
 
typedef struct
{
	TaskIDType TaskID;
	const char* TaskName;
	TaskStateEnum TaskState;	
	void *TaskParam;
	UInt32 TaskInterval;
	UInt32 TaskDelayTimer;
	UInt32 TaskInTimeMark;
	UInt32 TaskOutTimeMark;
	UInt32 CPUTimeMax;
	UInt32 CPUTimeMin;
	UInt32 CPUTimeAvg;
	UInt32 CPUTimeSum;
	UInt32 CPUTempCalculateSUM;
	UInt32 CPUTempCalculateNum;
	UInt32 WaitTimeStart;
	UInt32 WaitTime;
	TC_MutexLockStruct *WaitMutex;
	void (*TaskFunc)(void* TaskParam,void* TaskInfo);
}TaskStateInfoStruct;

typedef struct
{
	TaskIDType IDFree[TaskCountMax];
	UInt16 Count;
}TaskIDFreeListStruct;
typedef struct
{
	TaskStateInfoStruct TaskStateInfo[TaskCountMax];
	UInt16 Count;
}TaskStateInfoListStruct;
typedef struct
{
	TaskIDFreeListStruct TaskIDFreeList;
  TaskStateInfoListStruct TaskStateInfoList;
}TaskMuStruct;

#ifndef TC_TaskVar
extern const TaskMuStruct TaskMu;
#endif

void TC_TaskInit(void);
TaskIDType TC_Task_Add(void (*TaskFunc)(void* TaskParam,void * TaskInfo),const char* TaskName);
Bool TC_Task_Delete(TaskIDType TaskID);
void TC_TaskSetTimeBlock(TaskStateInfoStruct* Task,UInt32 WaitTime);
void TC_TaskSetMutexBlock(TaskStateInfoStruct* Task,TC_MutexLockStruct *Mutex);
void TC_TaskRun(void);

#endif
