#include "../TCSYS_Config.h"
#include "../Common/Lock.h"
#define TC_TaskVar
#include "TC_Task.h"
#include "../Device/DEV.h"
#include "string.h"

#define TC_TaskTimerVar DEV_GetTaskTimerValue()


static TaskMuStruct TaskMu;
static inline UInt32 TC_TaskTime_GetInterval(UInt32 StartTime,UInt32 EndTime)
{
	if(EndTime<StartTime)
	{
		return TaskTimeMax+EndTime-StartTime;
	}
	else
	{
		return EndTime-StartTime;
	}
}
void TC_TaskInit(void)
{
	UInt16 i=0;
	for(i=0;i<TaskCountMax;i++)
	{
		TaskMu.TaskIDFreeList.IDFree[i]=i;
	}
  TaskMu.TaskIDFreeList.Count=TaskCountMax;
}
TaskIDType GetNewTaskID(void)
{
	TaskIDType ret=TaskIDNone;
	if(TaskMu.TaskIDFreeList.Count>0)
	{
		ret=TaskMu.TaskIDFreeList.IDFree[TaskMu.TaskIDFreeList.Count-1];
		TaskMu.TaskIDFreeList.Count--;
	}
	return ret;
}
Bool FreeTaskID(TaskIDType TaskID)
{
	UInt16 i;
	if(TaskMu.TaskIDFreeList.Count>=TaskCountMax)
	{
		return TC_FALSE;
	}
	for(i=0;i<TaskMu.TaskIDFreeList.Count;i++)
	{
		if(TaskID==TaskMu.TaskIDFreeList.IDFree[i])
		{
			return TC_FALSE;
		}
	}
	TaskMu.TaskIDFreeList.IDFree[TaskMu.TaskIDFreeList.Count]=TaskID;
	TaskMu.TaskIDFreeList.Count++;
	return TC_TRUE;
}
TaskIDType TC_Task_Add(void (*TaskFunc)(void* TaskParam,void *TaskInfo),const char* TaskName)
{
	TaskIDType newid=TaskIDNone;
	if(TaskMu.TaskStateInfoList.Count<TaskCountMax)
	{
		newid=GetNewTaskID();
		memset(&TaskMu.TaskStateInfoList.TaskStateInfo[TaskMu.TaskStateInfoList.Count],0,sizeof(TaskStateInfoStruct));
		TaskMu.TaskStateInfoList.TaskStateInfo[TaskMu.TaskStateInfoList.Count].TaskFunc=TaskFunc;
		TaskMu.TaskStateInfoList.TaskStateInfo[TaskMu.TaskStateInfoList.Count].TaskName=TaskName;
		TaskMu.TaskStateInfoList.TaskStateInfo[TaskMu.TaskStateInfoList.Count].TaskID=newid;
		TaskMu.TaskStateInfoList.Count++;
	}
	return newid;
}
Bool TC_Task_Delete(TaskIDType TaskID)
{
	UInt16 i;
	if(TaskMu.TaskStateInfoList.Count<1)
	{
		return TC_FALSE;
	}
	for(i=0;i<TaskMu.TaskStateInfoList.Count;i++)
	{
		if(TaskID==TaskMu.TaskStateInfoList.TaskStateInfo[i].TaskID)
		{
			while(i<TaskMu.TaskIDFreeList.Count-1)
			{
				TaskMu.TaskStateInfoList.TaskStateInfo[i]=TaskMu.TaskStateInfoList.TaskStateInfo[i+1];
			}
			TaskMu.TaskStateInfoList.Count--;
			return TC_TRUE;
		}
	}
	return TC_FALSE;
}

static inline void TaskIN(TaskStateInfoStruct *TaskInfoP)
{	
	volatile UInt32 LastTaskIn;
	LastTaskIn=TaskInfoP->TaskInTimeMark=TaskInfoP->TaskInTimeMark;
	TaskInfoP->TaskInTimeMark=TC_TaskTimerVar;
	TaskInfoP->TaskInterval=TC_TaskTime_GetInterval(LastTaskIn,TaskInfoP->TaskInTimeMark);
}
static inline void TaskOUT(TaskStateInfoStruct *TaskInfoP)
{
	volatile UInt32 CycleTime;
	TaskInfoP->TaskOutTimeMark=TC_TaskTimerVar;
	CycleTime=TC_TaskTime_GetInterval(TaskInfoP->TaskInTimeMark,TaskInfoP->TaskOutTimeMark);
	if(CycleTime>TaskInfoP->CPUTimeMax)
	{
		TaskInfoP->CPUTimeMax=CycleTime;
	}
	if((CycleTime<TaskInfoP->CPUTimeMin)||(TaskInfoP->CPUTimeMin==0))
	{
		TaskInfoP->CPUTimeMin=CycleTime;
	}
	TaskInfoP->CPUTempCalculateSUM+=CycleTime;
	TaskInfoP->CPUTempCalculateNum++;
	if(TaskInfoP->CPUTempCalculateNum>=TaskCPUTimeCalculateNumMax)
	{					
		TaskInfoP->CPUTimeAvg=TaskInfoP->CPUTempCalculateSUM>>TaskCPUTimeCalculateNumMaxBit;
		TaskInfoP->CPUTempCalculateSUM=0;
		TaskInfoP->CPUTempCalculateNum=0;
	}
}
static inline void TaskWaitTimeBlock(TaskStateInfoStruct *TaskInfoP)
{
	volatile UInt32 CurrentTime,PassTime;
	CurrentTime=TC_TaskTimerVar;
	PassTime=TC_TaskTime_GetInterval(TaskInfoP->WaitTimeStart,CurrentTime);
	TaskInfoP->WaitTimeStart=CurrentTime;
	TaskInfoP->TaskDelayTimer+=PassTime;
	if(TaskInfoP->TaskDelayTimer>TaskInfoP->WaitTime)
	{
		TaskInfoP->TaskDelayTimer=0;
		TaskInfoP->TaskState=TaskStateEnum_Ready;
	}
//	else
//	{
//		TaskInfoP->TaskDelayTimer=0;
//		TaskInfoP->TaskState=TaskStateEnum_Ready;
//	}
}
static inline void TaskWaitMutex(TaskStateInfoStruct *TaskInfoP)
{
	if(TaskInfoP->WaitMutex->LockState==Locked)
	{
		TaskInfoP->TaskState=TaskStateEnum_Ready;
	}
}
void TC_TaskRun(void)
{
  UInt16 i;
  TaskStateInfoStruct *TaskInfoP;
  //UInt32 CycleTime,CurrentTime,PassTime;
	for(i=0;i<TaskMu.TaskStateInfoList.Count;i++)
	{
		TaskInfoP = &TaskMu.TaskStateInfoList.TaskStateInfo[i];
		switch(TaskInfoP->TaskState)
		{
			case TaskStateEnum_Ready:
				TaskIN(TaskInfoP);
				TaskInfoP->TaskFunc(TaskInfoP->TaskParam,TaskInfoP);
				TaskOUT(TaskInfoP);
			break;
			case TaskStateEnum_TimeBlock:
				TaskWaitTimeBlock(TaskInfoP);
			break;
			case TaskStateEnum_MutexBlock:
				TaskWaitMutex(TaskInfoP);
			break;
		}
	}
}
void TC_TaskSetTimeBlock(TaskStateInfoStruct* Task,UInt32 WaitTime)
{
	Task->TaskState=TaskStateEnum_TimeBlock;
	Task->WaitTime=WaitTime;
	Task->WaitTimeStart=TC_TaskTimerVar;
}
void TC_TaskSetMutexBlock(TaskStateInfoStruct* Task,TC_MutexLockStruct *Mutex)
{
	Task->TaskState=TaskStateEnum_MutexBlock;
	Task->WaitMutex=Mutex;
}
