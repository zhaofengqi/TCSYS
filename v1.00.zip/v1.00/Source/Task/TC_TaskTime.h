#ifndef TC_TaskTime_H
#define TC_TaskTime_H
#include "../TCSYS_Config.h"
#include "../Device/DEV.h"

#endif
