#include "NuMicro.h"
#include <string.h>
#include "../TCSYS_Config.h"
#include "DEV.h"
#include "../Common/FIFO.h"
#include "../Common/Lock.h"
#define DEV_UART4_Var
#include "DEV_UART4.h"

 

static void Init(void);
static Bool Open(TaskIDType TaskID);
static Bool Close(TaskIDType TaskID);
static UInt32 Write(void * Buf, UInt32 Count );
static UInt32 Read(void * Buf, UInt32 Count);
static Bool IOControl(UInt16 Cmd,void* param,void* Ret);
static UInt32 Task(void);

#define UART4SendFIFOSize 500
static Byte WriteBuffer[UART4SendFIFOSize];
static TC_FIFOStruct SendFIFO;
#define UART4ReceiveFIFOSize 500
static Byte ReadBuffer[UART4ReceiveFIFOSize];
static TC_FIFOStruct ReceiveFIFO;  

static const UART4ParamStruct DefaultParam=
{
 .Baudrate=UART4BaudrateEnum_115200,
 .Parity=UART4ParityEnum_None,
 .StopBit=UART4StopBitEnum_1,
};
DevNodeStruct DEVNode_UART4=
{
 .DevInfo=
 {
 	.DevName="UART4",
	.Init=Init,
	.Open= Open,
	.Close=Close,
	.Read=Read,
	.Write=Write,
	.IOControl=IOControl,
	.Task=Task,
 },
 .DevState=
 {
  .DelayTimer=0,
	.DelayTime=0,
	.State=DevStateEnum_Sleep,
 },
 .MutexLock=
 {
   .LockState=TC_FALSE,
	 .TaskID=TaskIDNone,
 }
};


static void Init(void)
{
 TC_FIFO_Init(&SendFIFO,WriteBuffer,UART4SendFIFOSize);
 TC_FIFO_Init(&ReceiveFIFO,ReadBuffer,UART4ReceiveFIFOSize);
 SYS_UnlockReg();
 CLK_EnableModuleClock(UART4_MODULE);//ʹ��UART0 ʱ��
 CLK_SetModuleClock(UART4_MODULE, CLK_CLKSEL3_UART4SEL_PLL, CLK_CLKDIV4_UART4(9));//UART0 ʱ�� PLL/10 = 5MHz		  
 //SYS->GPD_MFPL &= ~(SYS_GPD_MFPL_PD2MFP_Msk | SYS_GPD_MFPL_PD3MFP_Msk);
 //SYS->GPD_MFPL |= (SYS_GPD_MFPL_PD2MFP_UART0_RXD | SYS_GPD_MFPL_PD3MFP_UART0_TXD);
 SYS->GPH_MFPH &= ~(SYS_GPH_MFPH_PH10MFP_Msk | SYS_GPH_MFPH_PH11MFP_Msk);
 SYS->GPH_MFPH |= (SYS_GPH_MFPH_PH11MFP_UART4_RXD | SYS_GPH_MFPH_PH10MFP_UART4_TXD);	
 SYS_LockReg();
 SYS_ResetModule(UART4_RST);
 UART_SetTimeoutCnt(UART4,100);
 UART_ENABLE_INT(UART4,UART_INTEN_RXTOIEN_Msk|UART_INTEN_RDAIEN_Msk|UART_INTEN_TXENDIEN_Msk);
 
}
Bool Open(TaskIDType TaskID)
{
 NVIC_EnableIRQ(UART4_IRQn);
 UART_Open(UART4,DefaultParam.Baudrate, DefaultParam.Parity + DefaultParam.StopBit + UART_WORD_LEN_8);
 return TC_TRUE;
}
Bool Close(TaskIDType TaskID)
{
 return TC_TRUE;
}
UInt32 Write(void * Buf, UInt32 Count )
{
	UInt32 ret= TC_FIFO_Write(&SendFIFO,Buf,Count,TC_FALSE);
	UART_ENABLE_INT(UART4,UART_INTEN_TXENDIEN_Msk);
	return ret;
}
UInt32 Read(void * Buf, UInt32 Count)
{
	return TC_FIFO_Read(&ReceiveFIFO,Buf,Count,TC_FALSE);
}

Bool IOControl(UInt16 Cmd,void* Param,void* Ret)
{
	Bool ret= TC_FALSE;
	switch(Cmd)
	{
		case (UInt16)(DevCMD_GetUnreadCount):
			*((UInt16*)Ret)=ReceiveFIFO.UnReadedCount;
			ret = TC_TRUE;
		break;
		case (UInt16)(DevCMD_GetUnwriteCount):
			*((UInt16*)Ret)=ReceiveFIFO.UnWritedCount;
			ret = TC_TRUE;
		break;
	}
	return ret;
}


static UInt32 Task(void)
{
 return 0;
}

void UART4_IRQHandler(void)
{
	Byte Data;
	if(UART_GET_INT_FLAG(UART4,UART_INTSTS_RDAIF_Msk|UART_INTSTS_RXTOINT_Msk))//�����ж� 
	{
		while(!UART_GET_RX_EMPTY(UART4))
		{
			Data=UART_READ(UART4);
			if(ReceiveFIFO.UnWritedCount>0)
			{
				TC_FIFO_WriteChUnsafe(&ReceiveFIFO,Data);
			}
		}
	}
	if(UART_GET_INT_FLAG(UART4,UART_INTSTS_TXENDIF_Msk))//�����ж�
	{
		while((!UART_IS_TX_FULL(UART4)) && (SendFIFO.UnReadedCount>0))
		{
			Data=TC_FIFO_ReadChUnsafe(&SendFIFO);
			UART_WRITE(UART4,Data);
		}
		if(SendFIFO.UnReadedCount==0)
		{
			UART_DISABLE_INT(UART4,UART_INTEN_TXENDIEN_Msk);
		}
	}
}
