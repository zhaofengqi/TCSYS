#include "../TCSYS_Config.h"
#include "M480.h"
#include "DEV.h"
#include "core_cm4.h"
DevListStruct DevListMu;



/***************��ֲ�޸Ĳ���***********************/


void DEV_InitBoard(void)
{
	SYS_UnlockReg();
	//��Ƶ�趨
  CLK_EnableXtalRC(CLK_PWRCTL_HIRCEN_Msk);
  CLK_WaitClockReady(CLK_STATUS_HIRCSTB_Msk);
  CLK_SetCoreClock(FREQ_192MHZ); 
	CLK->PCLKDIV = (CLK_PCLKDIV_PCLK0DIV2 | CLK_PCLKDIV_PCLK1DIV2); // PCLK0 PCLK1 96MHz
	SystemCoreClockUpdate();
	SYS_LockReg();
	
	//ʹ��һ����ʱ����������������ȣ��˶�ʱ����Ҫ�ж���Ӧ
	CLK_EnableModuleClock(TMR0_MODULE);
	CLK_SetModuleClock(TMR0_MODULE,CLK_CLKSEL1_TMR0SEL_PCLK0,1);
	TIMER_SET_PRESCALE_VALUE(TIMER0,95);
	TIMER0->CTL |= TIMER_PERIODIC_MODE;
	TIMER_SET_CMP_VALUE(TIMER0,DevTimerMax);
	TIMER_EnableInt(TIMER0);
	NVIC_EnableIRQ(TMR0_IRQn);
	TIMER_Start(TIMER0);
	
	
	//ʹ��һ����ʱ������Ӧ�ò������ʱ���˶�ʱ������Ҫ�ж���Ӧ
	CLK_EnableModuleClock(TMR1_MODULE);
	CLK_SetModuleClock(TMR1_MODULE,CLK_CLKSEL1_TMR1SEL_PCLK0,1);
	TIMER_SET_PRESCALE_VALUE(TIMER1,95);
	TIMER1->CTL |= TIMER_PERIODIC_MODE;
	//TIMER_Open(TIMER1,TIMER_PERIODIC_MODE,1000000);
	TIMER_SET_CMP_VALUE(TIMER1,DevTimerMax);
	TIMER_Start(TIMER1);
}	




void TMR0_IRQHandler(void)
{
	UInt16 i;
	UInt32 NextTimerCounter=DevTimerMax;
  UInt32 TempTime=0;
	UInt32 CurrentCnt=TIMER_GetCounter(TIMER0);
	TIMER_ClearIntFlag(TIMER0);
	for(i=0;i<DevListMu.DevCount;i++)
	{
		switch(DevListMu.Devs[i]->DevState.State)
		{
			case DevStateEnum_Sleep:
			break;
			case DevStateEnum_Active:
				TempTime=DevListMu.Devs[i]->DevInfo.Task();
			  if(TempTime==DevTimerMax)
				{
					DevListMu.Devs[i]->DevState.State=DevStateEnum_Sleep;
					DevListMu.Devs[i]->DevState.DelayTimer=TempTime;
				}
				else
				{
					if(TempTime<NextTimerCounter)
					{
						NextTimerCounter = TempTime;
					}
				}
			break;
			case DevStateEnum_Delay:
				if(DevListMu.Devs[i]->DevState.DelayTimer>DevListMu.TimerRegValue)
				{
					DevListMu.Devs[i]->DevState.DelayTimer-=DevListMu.TimerRegValue;
					if(DevListMu.Devs[i]->DevState.DelayTimer<NextTimerCounter)
					{
						NextTimerCounter = DevListMu.Devs[i]->DevState.DelayTimer;
					}
				}
				else
				{
					NextTimerCounter=0;
					DevListMu.Devs[i]->DevState.DelayTimer=0;
					DevListMu.Devs[i]->DevState.State=DevStateEnum_Active;
				}
			break;
		}
		
	}
}
/***************END ��ֲ�޸Ĳ��� END***********************/

Bool DEV_Regist(const DevNodeStruct* DevNode)
{
  UInt16 i;
	if(DevListMu.DevCount>=DevCountMax)
	{
		return TC_FALSE;
	}
	for(i=0;i<DevListMu.DevCount;i++)
	{
		if(DevNode==DevListMu.Devs[i])
		{
			return TC_FALSE;
		}
	}
	DevListMu.Devs[DevListMu.DevCount]=(DevNodeStruct*)DevNode;
	DevListMu.DevCount++;
	return TC_TRUE;
}
Bool DEV_UnRegist(const DevNodeStruct* DevNode)
{
  UInt16 i;
	for(i=0;i<DevListMu.DevCount;i++)
	{
		if(DevNode==DevListMu.Devs[i])
		{
			while(i<DevListMu.DevCount-1)
			{
				DevListMu.Devs[i]=DevListMu.Devs[i+1];
			}
			DevListMu.DevCount--;
			return TC_TRUE;
		}
	} 
	return TC_FALSE;
}
 
void DEV_SetActive(const DevNodeStruct* DevNode)
{
	DevNodeStruct* DevNodeN=(DevNodeStruct*)DevNode;
	DevNodeN->DevState.State=DevStateEnum_Active;
	DevNodeN->DevState.DelayTimer=0;
	DevListMu.TimerRegValue=DEV_GetTimerValue();
}
void DEV_Init(const DevNodeStruct* DevNode)
{
	DevNode->DevInfo.Init();
}
Bool DEV_Open(const DevNodeStruct* DevNode,TaskIDType TaskID)
{
	DevNodeStruct* DevNodeN=(DevNodeStruct*)DevNode;
	if(DevNodeN==NULL)
	{
		return TC_FALSE;
	}
	if(DevNodeN->MutexLock.LockState==1)
	{
		return TC_FALSE;
	}
	DevNodeN->MutexLock.LockState=1;
	DevNodeN->MutexLock.TaskID=TaskID;
	return DevNodeN->DevInfo.Open(TaskID);
}
Bool DEV_Close(const DevNodeStruct* DevNode,TaskIDType TaskID)
{
	if(DevNode==NULL)
	{
		return TC_FALSE;
	}
	if(DevNode==NULL)
	{
		return TC_FALSE;
	}
	if((DevNode->MutexLock.LockState==1)&&(DevNode->MutexLock.TaskID!=TaskID))
	{
		return TC_FALSE;
	}
	return DevNode->DevInfo.Close(TaskID);
}
Int32 DEV_Read(const DevNodeStruct* DevNode,TaskIDType TaskID,void* Buffer,UInt32 Count)
{
	UInt32 ret;
	if(DevNode==NULL)
	{
		return 0;
	}
	if((DevNode->MutexLock.LockState==1)&&(DevNode->MutexLock.TaskID!=TaskID))
	{
		return TC_FALSE;
	}
	ret=DevNode->DevInfo.Read(Buffer,Count);
	return ret;
}
Int32 DEV_Write(const DevNodeStruct* DevNode,TaskIDType TaskID,void* Buffer,UInt32 Count)
{
	UInt32 ret;
	if(DevNode==NULL)
	{
		return 0;
	}
	if((DevNode->MutexLock.LockState==1)&&(DevNode->MutexLock.TaskID!=TaskID))
	{
		return TC_FALSE;
	}
	ret=DevNode->DevInfo.Write(Buffer,Count);
	return ret;
}
Bool DEV_IOControl (const DevNodeStruct* DevNode,TaskIDType TaskID,UInt16 Cmd,void* Param,void* Ret)
{
	if(DevNode==NULL)
	{
		return TC_FALSE;
	}
	if((DevNode->MutexLock.LockState==1)&&(DevNode->MutexLock.TaskID!=TaskID))
	{
		return TC_FALSE;
	}
  return DevNode->DevInfo.IOControl(Cmd,Param,Ret);
}

