#include "NuMicro.h"
#include <string.h>
#include "../TCSYS_Config.h"
#include "DEV.h"
#include "../Common/FIFO.h"
#include "../Common/Lock.h"
#define DEV_Debug_Var
#include "DEV_DebugIO.h"
#include "uart.h"
 

static void Init(void);
static Bool Open(TaskIDType TaskID);
static Bool Close(TaskIDType TaskID);
static UInt32 Write(void * Buf, UInt32 Count );
static UInt32 Read(void * Buf, UInt32 Count);
static Bool IOControl(UInt16 Cmd,void* param,void* Ret);
static UInt32 Task(void);

#define DebugIOSendFIFOSize 500
static Byte WriteBuffer[DebugIOSendFIFOSize];
static TC_FIFOStruct SendFIFO;
#define DebugIOReceiveFIFOSize 500
static Byte ReadBuffer[DebugIOReceiveFIFOSize];
static TC_FIFOStruct ReceiveFIFO;  

static const DebugIOParamStruct DefaultParam=
{
 .Baudrate=DebugIOBaudrateEnum_115200,
 .Parity=DebugIOParityEnum_None,
 .StopBit=DebugIOStopBitEnum_1,
};
DevNodeStruct DEVNode_DebugIO=
{
 .DevInfo=
 {
 	.DevName="DebugIO",
	.Init=Init,
	.Open= Open,
	.Close=Close,
	.Read=Read,
	.Write=Write,
	.IOControl=IOControl,
	.Task=Task,
 },
 .DevState=
 {
  .DelayTimer=0,
	.DelayTime=0,
	.State=DevStateEnum_Sleep,
 },
 .MutexLock=
 {
   .LockState=TC_FALSE,
	 .TaskID=TaskIDNone,
 }
};


static void Init(void)
{
 TC_FIFO_Init(&SendFIFO,WriteBuffer,DebugIOSendFIFOSize);
 TC_FIFO_Init(&ReceiveFIFO,ReadBuffer,DebugIOReceiveFIFOSize);
 SYS_UnlockReg();
 CLK_EnableModuleClock(UART0_MODULE);//ʹ��UART0 ʱ��
 CLK_SetModuleClock(UART0_MODULE, CLK_CLKSEL1_UART0SEL_PLL, CLK_CLKDIV0_UART0(9));//UART0 ʱ�� PLL/10 = 5MHz		  
 //SYS->GPD_MFPL &= ~(SYS_GPD_MFPL_PD2MFP_Msk | SYS_GPD_MFPL_PD3MFP_Msk);
 //SYS->GPD_MFPL |= (SYS_GPD_MFPL_PD2MFP_UART0_RXD | SYS_GPD_MFPL_PD3MFP_UART0_TXD);
 SYS->GPB_MFPH &= ~(SYS_GPB_MFPH_PB13MFP_Msk | SYS_GPB_MFPH_PB12MFP_Msk);
 SYS->GPB_MFPH |= (SYS_GPB_MFPH_PB12MFP_UART0_RXD | SYS_GPB_MFPH_PB13MFP_UART0_TXD);	
 SYS_LockReg();
 SYS_ResetModule(UART0_RST);
 UART_SetTimeoutCnt(UART0,100);
 UART_ENABLE_INT(UART0,UART_INTEN_RXTOIEN_Msk|UART_INTEN_RDAIEN_Msk|UART_INTEN_TXENDIEN_Msk);
 
}
static Bool Open(TaskIDType TaskID)
{
 NVIC_EnableIRQ(UART0_IRQn);
 UART_Open(UART0,DefaultParam.Baudrate, DefaultParam.Parity + DefaultParam.StopBit + UART_WORD_LEN_8);
 
 return TC_TRUE;
}
static Bool Close(TaskIDType TaskID)
{
 return TC_TRUE;
}
static UInt32 Write(void * Buf, UInt32 Count )
{
	UInt32 ret= TC_FIFO_Write(&SendFIFO,Buf,Count,TC_FALSE);
	UART_ENABLE_INT(UART0,UART_INTEN_TXENDIEN_Msk);
	return ret;
}
static UInt32 Read(void * Buf, UInt32 Count)
{
	return TC_FIFO_Read(&ReceiveFIFO,Buf,Count,TC_FALSE);
}


static Bool IOControl(UInt16 Cmd,void* Param,void* Ret)
{
	Bool ret= TC_FALSE;
	switch(Cmd)
	{
		case (UInt16)(DevCMD_GetUnreadCount):
			*((UInt16*)Ret)=ReceiveFIFO.UnReadedCount;
			ret = TC_TRUE;
		break;
		case (UInt16)(DevCMD_GetUnwriteCount):
			*((UInt16*)Ret)=ReceiveFIFO.UnWritedCount;
			ret = TC_TRUE;
		break;
	}
	return ret;
}
 
static UInt32 Task(void)
{

	return 0;
}

void UART0_IRQHandler(void)
{
	Byte Data;
	if(UART_GET_INT_FLAG(UART0,UART_INTSTS_RDAIF_Msk|UART_INTSTS_RXTOINT_Msk))//�����ж� 
	{
		while(!UART_GET_RX_EMPTY(UART0))
		{
			Data=UART_READ(UART0);
			if(ReceiveFIFO.UnWritedCount>0)
			{
				TC_FIFO_WriteChUnsafe(&ReceiveFIFO,Data);
			}
		}
	}
	if(UART_GET_INT_FLAG(UART0,UART_INTSTS_TXENDIF_Msk))//�����ж�
	{
		while((!UART_IS_TX_FULL(UART0)) && (SendFIFO.UnReadedCount>0))
		{
			Data=TC_FIFO_ReadChUnsafe(&SendFIFO);
			UART_WRITE(UART0,Data);
		}
		if(SendFIFO.UnReadedCount==0)
		{
			UART_DISABLE_INT(UART0,UART_INTEN_TXENDIEN_Msk);
		}
	}
}
