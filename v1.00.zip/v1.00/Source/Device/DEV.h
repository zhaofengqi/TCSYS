#ifndef DEV_H
#define DEV_H

#include "../TCSYS_Config.h"
#include "../Common/Lock.h"
#include "M480.h"

#define DevCMD_Reset 0
#define DevCMD_Start 1
#define DevCMD_Stop 2
#define DevCMD_GetState 3
#define DevCMD_GetUnreadCount 4
#define DevCMD_GetUnwriteCount 5
#define DevCMD_SetParam 6
#define DevCMD_GetParam 7

typedef enum
{
	DevStateEnum_Sleep,
	DevStateEnum_Delay,
	DevStateEnum_Active,

}DevStateEnum;
typedef struct
{
 UInt32 DelayTimer;
 UInt32 DelayTime;
 DevStateEnum State;
}DevStateStruct;
typedef struct
{
  SByte* DevName;
	void (*Init)(void);
	Bool (*Open)(TaskIDType TaskID);
	Bool (*Close)(TaskIDType TaskID);
	UInt32 (*Read)(void * Buf, UInt32 Count);
	UInt32 (*Write)(void * Buf, UInt32 Count );
	Bool (*IOControl)(UInt16 Cmd,void* Param,void* Ret);
	UInt32 (*Task)();
}DevInfoStruct;
typedef struct
{
  DevInfoStruct DevInfo;
	DevStateStruct DevState;
	TC_MutexLockStruct MutexLock;
}DevNodeStruct;

typedef struct
{
	DevNodeStruct *Devs[DevCountMax];
	UInt16 DevCount;
	UInt32 TimerRegValue;
}DevListStruct;

#define DEV_SetTimerValue(TimerValue) TIMER_SET_CMP_VALUE(TIMER0,TimerValue);
#define DEV_GetTimerValue() TIMER_GetCounter(TIMER0);

#define DEV_GetTaskTimerValue() TIMER_GetCounter(TIMER1);

void DEV_InitBoard(void);
void DEV_Init(const DevNodeStruct* DevNode);
Bool DEV_Open(const DevNodeStruct* DevNode,TaskIDType TaskID);
Bool DEV_Close(const DevNodeStruct* DevNode,TaskIDType TaskID);
Int32 DEV_Read(const DevNodeStruct* DevNode,TaskIDType TaskID,void* Buffer,UInt32 Count);
Bool DEV_IOControl (const DevNodeStruct* DevNode,TaskIDType TaskID,UInt16 Cmd,void* Param,void* Ret);
Int32 DEV_Write(const DevNodeStruct* DevNode,TaskIDType TaskID,void* Buffer,UInt32 Count);

#endif
