#ifndef DEV_Debug_H
#define DEV_Debug_H
#include "../TCSYS_Config.h"
#include "DEV.h"
#include "NuMicro.h"
typedef enum
{
 DebugIOBaudrateEnum_1200=1200,
 DebugIOBaudrateEnum_2400=2400,
 DebugIOBaudrateEnum_9600=9600,
 DebugIOBaudrateEnum_19200=2400,
 DebugIOBaudrateEnum_38400=38400,
 DebugIOBaudrateEnum_57600=57600,
 DebugIOBaudrateEnum_115200=115200,
 DebugIOBaudrateEnum_230400=230400,
 DebugIOBaudrateEnum_256000=256000,
 DebugIOBaudrateEnum_460800=460800,
 DebugIOBaudrateEnum_512000=512000,
 DebugIOBaudrateEnum_1024000=1024000,
}DebugIOBaudrateEnum;
typedef enum
{
	DebugIOParityEnum_None=UART_PARITY_NONE,
	DebugIOParityEnum_Odd=UART_PARITY_ODD,
	DebugIOParityEnum_Even=UART_PARITY_EVEN,
}DebugIOParityEnum;
typedef enum
{
	DebugIOStopBitEnum_1=UART_STOP_BIT_1,
	DebugIOStopBitEnum_1_5=UART_STOP_BIT_1_5,
	DebugIOStopBitEnum_2=UART_STOP_BIT_2,
}DebugIOStopBitEnum;
typedef struct
{
	DebugIOBaudrateEnum Baudrate;
	DebugIOParityEnum Parity;
	DebugIOStopBitEnum StopBit;
}DebugIOParamStruct;

typedef enum
{
	DebugIOCmdEnum_RegistCmd,
	DebugIOCmdEnum_DeregistCmd,
}DebugIOCmdEnum;


#ifndef DEV_Debug_Var
extern const DevNodeStruct DEVNode_DebugIO;
#endif
#endif

