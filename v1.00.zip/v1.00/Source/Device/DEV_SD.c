#include "NuMicro.h"
#include <string.h>
#include "../TCSYS_Config.h"
#include "DEV.h"
#include "../Common/FIFO.h"
#include "../Common/Lock.h"
#include "DEV_SD.h"
static void Init(void);
static Bool Open(TaskIDType TaskID);
static Bool Close(TaskIDType TaskID);
static UInt32 Write(void * Buf, UInt32 Count );
static UInt32 Read(void * Buf, UInt32 Count);
static Bool IOControl(UInt16 Cmd,void* param,void* Ret);
static UInt32 Task(void);

#define UART4SendFIFOSize 500
static Byte WriteBuffer[UART4SendFIFOSize];
static TC_FIFOStruct SendFIFO;
#define UART4ReceiveFIFOSize 500
static Byte ReadBuffer[UART4ReceiveFIFOSize];
static TC_FIFOStruct ReceiveFIFO;  

DevNodeStruct DEVNode_SD0=
{
 .DevInfo=
 {
 	.DevName="SD0",
	.Init=Init,
	.Open= Open,
	.Close=Close,
	.Read=Read,
	.Write=Write,
	.IOControl=IOControl,
	.Task=Task,
 },
 .DevState=
 {
  .DelayTimer=0,
	.DelayTime=0,
	.State=DevStateEnum_Sleep,
 },
 .MutexLock=
 {
   .LockState=TC_FALSE,
	 .TaskID=TaskIDNone,
 }
};


static void Init(void)
{
 TC_FIFO_Init(&SendFIFO,WriteBuffer,UART4SendFIFOSize);
 TC_FIFO_Init(&ReceiveFIFO,ReadBuffer,UART4ReceiveFIFOSize);
 SYS_UnlockReg();
 CLK_EnableModuleClock(SDH0_MODULE);//ʹ��UART0 ʱ��
 CLK_SetModuleClock(SDH0_MODULE, CLK_CLKSEL0_SDH0SEL_HIRC, CLK_CLKDIV0_SDH0(31));//SD0 ʱ�� HIRC/32 = 12MHz/32=375K
 
 SYS->GPB_MFPL &= ~(SYS_GPB_MFPL_PB4MFP_Msk | SYS_GPB_MFPL_PB5MFP_Msk);
 SYS->GPB_MFPL |= (SYS_GPB_MFPL_PB4MFP_SD0_DAT2 | SYS_GPB_MFPL_PB5MFP_SD0_DAT3);

 SYS->GPE_MFPL &= ~(SYS_GPE_MFPL_PE2MFP_Msk | SYS_GPE_MFPL_PE3MFP_Msk | SYS_GPE_MFPL_PE6MFP_Msk | SYS_GPE_MFPL_PE7MFP_Msk);
 SYS->GPE_MFPL |= (SYS_GPE_MFPL_PE2MFP_SD0_DAT0 | SYS_GPE_MFPL_PE3MFP_SD0_DAT1 | SYS_GPE_MFPL_PE6MFP_SD0_CLK | SYS_GPE_MFPL_PE7MFP_SD0_CMD);
	
 SYS->GPD_MFPH &= ~(SYS_GPD_MFPH_PD13MFP_Msk);
 SYS->GPD_MFPH |= (SYS_GPD_MFPH_PD13MFP_SD0_nCD );
	
 SYS_LockReg();
 SYS_ResetModule(SDH0_RST); 
}
Bool Open(TaskIDType TaskID)
{
 SDH0->GCTL = SDH_GCTL_GCTLRST_Msk | SDH_GCTL_SDEN_Msk;
	
 SDH0->GINTEN = 0ul;
 SDH0->CTL &= ~SDH_CTL_SDNWR_Msk;
 SDH0->CTL |=  0x09ul << SDH_CTL_SDNWR_Pos;   /* set SDNWR = 9 */
 SDH0->CTL &= ~SDH_CTL_BLKCNT_Msk;
 SDH0->CTL |=  0x01ul << SDH_CTL_BLKCNT_Pos;  /* set BLKCNT = 1 */
 SDH0->CTL &= ~SDH_CTL_DBW_Msk;               /* SD 1-bit data bus */
	
 return TC_TRUE;
}
Bool Close(TaskIDType TaskID)
{
 return TC_TRUE;
}
UInt32 Write(void * Buf, UInt32 Count )
{
 
}
UInt32 Read(void * Buf, UInt32 Count)
{
 
}

Bool IOControl(UInt16 Cmd,void* Param,void* Ret)
{
	Bool ret= TC_FALSE;
	switch(Cmd)
	{
		case (UInt16)(DevCMD_GetUnreadCount):
			//*((UInt16*)Ret)=ReceiveFIFO.UnReadedCount;
			ret = TC_TRUE;
		break;
		case (UInt16)(DevCMD_GetUnwriteCount):
			//*((UInt16*)Ret)=ReceiveFIFO.UnWritedCount;
			ret = TC_TRUE;
		break;
	}
	return ret;
}


static UInt32 Task(void)
{
 return 0;
}
