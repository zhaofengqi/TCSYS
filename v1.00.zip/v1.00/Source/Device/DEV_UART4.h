#ifndef DEV_Debug_H
#define DEV_Debug_H
#include "../TCSYS_Config.h"
#include "DEV.h"
#include "NuMicro.h"
typedef enum
{
 UART4BaudrateEnum_1200=1200,
 UART4BaudrateEnum_2400=2400,
 UART4BaudrateEnum_9600=9600,
 UART4BaudrateEnum_19200=2400,
 UART4BaudrateEnum_38400=38400,
 UART4BaudrateEnum_57600=57600,
 UART4BaudrateEnum_115200=115200,
 UART4BaudrateEnum_230400=230400,
 UART4BaudrateEnum_256000=256000,
 UART4BaudrateEnum_460800=460800,
 UART4BaudrateEnum_512000=512000,
 UART4BaudrateEnum_1024000=1024000,
}UART4BaudrateEnum;
typedef enum
{
	UART4ParityEnum_None=UART_PARITY_NONE,
	UART4ParityEnum_Odd=UART_PARITY_ODD,
	UART4ParityEnum_Even=UART_PARITY_EVEN,
}UART4ParityEnum;
typedef enum
{
	UART4StopBitEnum_1=UART_STOP_BIT_1,
	UART4StopBitEnum_1_5=UART_STOP_BIT_1_5,
	UART4StopBitEnum_2=UART_STOP_BIT_2,
}UART4StopBitEnum;
typedef struct
{
	UART4BaudrateEnum Baudrate;
	UART4ParityEnum Parity;
	UART4StopBitEnum StopBit;
}UART4ParamStruct;

typedef enum
{
	UART4CmdEnum_RegistCmd,
	UART4CmdEnum_DeregistCmd,
	UART4CmdEnum_GetFIFOState,
}UART4CmdEnum;
typedef enum
{
	UART4FIFOType_Receive,
	UART4FIFOType_Send,
}UART4FIFOType;



#ifndef DEV_UART4_Var
extern const DevNodeStruct DEVNode_UART4;
#endif
#endif

