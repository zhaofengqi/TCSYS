#include "../TCSYS_Config.h"
#include "Lock.h"

Bool TC_MutexLock(TC_MutexLockStruct* Mutex,TaskIDType TaskID)
{
	if(Mutex->LockState==Locked)
	{
		return TC_FALSE;
	}
	else
	{
		Mutex->LockState=Locked;
		Mutex->TaskID=TaskID;
		return TC_TRUE;
	}
}
Bool TC_MutexUnlock(TC_MutexLockStruct* Mutex,TaskIDType TaskID)
{
	if((Mutex->LockState==Locked)&&(Mutex->TaskID==TaskID))
	{
		Mutex->LockState=Unlocked;
		Mutex->TaskID=TaskIDNone;
		return TC_TRUE;
	}
	else
	{
		return TC_FALSE;
	}
}
