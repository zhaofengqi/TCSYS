#ifndef LOCK_H
#define LOCK_H
#include "../TCSYS_Config.h"
#define SignalMaxCount 10 //���32
#define Locked 1
#define Unlocked 0
typedef struct
{
	TaskIDType TaskID;
	Bool LockState;
}TC_MutexLockStruct;

Bool TC_MutexLock(TC_MutexLockStruct* Mutex,TaskIDType TaskID);
Bool TC_MutexUnlock(TC_MutexLockStruct* Mutex,TaskIDType TaskID);
#endif
