#ifndef FIFO_H
#define FIFO_H
#include "../TCSYS_Config.h"
#define ReadCurrentALL 0xFFFF
#define FIFOLock_Lock 1
#define FIFOLock_Unlock 0
typedef struct
{
	UInt16 TotalSize;
	UInt16 ReadPtr;
	UInt16 WritePtr;
	UInt16 UnWritedCount;
	UInt16 UnReadedCount;
	Byte* Buffer;
	UInt16 LockCount;
}TC_FIFOStruct;

inline Byte TC_FIFO_ReadChUnsafe(TC_FIFOStruct *FIFO)
{
	Byte Ret;
	if(FIFO->UnReadedCount>0)
	{
		Ret=FIFO->Buffer[FIFO->ReadPtr];
		FIFO->ReadPtr++;
		if(FIFO->ReadPtr>=FIFO->TotalSize)
		{
			FIFO->ReadPtr=0;
		}
		FIFO->UnReadedCount--;
		FIFO->UnWritedCount++;
	}
	return Ret;
}


inline void TC_FIFO_WriteChUnsafe(TC_FIFOStruct *FIFO,Byte Data)
{
	if(FIFO->UnWritedCount>0)
	{
		FIFO->Buffer[FIFO->WritePtr]=Data;
		FIFO->WritePtr++;
		if(FIFO->WritePtr>=FIFO->TotalSize)
		{
			FIFO->WritePtr=0;
		}
		FIFO->UnReadedCount++;
		FIFO->UnWritedCount--;
	}
}

void TC_FIFO_Init(TC_FIFOStruct *FIFO,Byte* Buffer,UInt16 BufferSize);
UInt16 TC_FIFO_Read(TC_FIFOStruct *FIFO,Byte* Dest,UInt16 ReadSize,Bool IsSafe);
UInt16 TC_FIFO_Write(TC_FIFOStruct *FIFO,Byte* Source,UInt16 WriteSize,Bool IsSafe);
#endif
