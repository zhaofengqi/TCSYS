#include "../TCSYS_Config.h"
#include <string.h>
#include "Queue.h"

Bool TC_QueueScoll(TC_QueueStruct* PQueue,UInt16 ScollCount,Bool IsSafe)
{
	if(ScollCount<=PQueue->WritePtr)
	{
		if(IsSafe)
		{
			CriticalIn;
		}
		memcpy(PQueue->Memory,&PQueue->Memory[ScollCount],(PQueue->Size-ScollCount));
		PQueue->WritePtr-=ScollCount;
		if(IsSafe)
		{
			CriticalOut;
		}
		return TC_TRUE;
	}
	return TC_FALSE;
}

UInt16 TC_QueueWrite(TC_QueueStruct* PQueue,Byte* Data,UInt16 Length,Bool IsSafe,Bool DataCopy)
{
	if((PQueue->WritePtr+Length)<=PQueue->Size)
	{
		if(IsSafe)
		{
			CriticalIn;
		}
		if(DataCopy)
		{
			memcpy(&PQueue->Memory[PQueue->WritePtr],Data,Length);
		}
		PQueue->WritePtr+=Length;
		if(IsSafe)
		{
			CriticalOut;
		}
		return TC_TRUE;
	}
	return TC_FALSE;
}
