#ifndef Queue_H
#define Queue_H
#include "../TCSYS_Config.h"
typedef struct
{
	Byte* Memory;
	UInt16 Size;
	UInt16 WritePtr;
}TC_QueueStruct;
Bool TC_QueueScoll(TC_QueueStruct* PQueue,UInt16 ScollCount,Bool IsSafe);
UInt16 TC_QueueWrite(TC_QueueStruct* PQueue,Byte* Data,UInt16 Length,Bool IsSafe,Bool DataCopy);
#endif
