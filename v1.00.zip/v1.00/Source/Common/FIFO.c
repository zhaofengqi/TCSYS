#include "../TCSYS_Config.h"
#include "FIFO.h"
#define ReadCurrentALL 0xFFFF
#define FIFOLock_Lock 1
#define FIFOLock_Unlock 0


void TC_FIFO_Init(TC_FIFOStruct *FIFO,Byte* Buffer,UInt16 BufferSize)
{
	FIFO->Buffer=Buffer;
	FIFO->TotalSize=BufferSize;
	FIFO->ReadPtr=0;
	FIFO->WritePtr=0;
	FIFO->UnWritedCount=BufferSize;
	FIFO->UnReadedCount=0;
}


UInt16 TC_FIFO_Read(TC_FIFOStruct *FIFO,Byte* Dest,UInt16 ReadSize,Bool IsSafe)
{
	UInt16 i;
	if(ReadSize>FIFO->UnReadedCount)
	{
		ReadSize=FIFO->UnReadedCount;
	}
//	if(IsSafe)
//	{
//		CriticalIn;
//	}
	for(i=0;i<ReadSize;i++)
	{
		Dest[i]=FIFO->Buffer[FIFO->ReadPtr];
		FIFO->ReadPtr++;
		if(FIFO->ReadPtr>=FIFO->TotalSize)
		{
			FIFO->ReadPtr=0;
		}
		CriticalIn;
		FIFO->UnWritedCount++;
		FIFO->UnReadedCount--;
		CriticalOut;
	}
//	if(IsSafe)
//	{
//		CriticalOut;
//	}
	return ReadSize;
}

UInt16 TC_FIFO_Write(TC_FIFOStruct *FIFO,Byte* Source,UInt16 WriteSize,Bool IsSafe)
{
	UInt16 i;
	if(WriteSize>FIFO->UnWritedCount)
	{
		WriteSize=0;
	}
	else
	{
//		if(IsSafe)
//		{
//			CriticalIn;
//		}
		for(i=0;i<WriteSize;i++)
		{
			FIFO->Buffer[FIFO->WritePtr]=Source[i];
			FIFO->WritePtr++;
			if(FIFO->WritePtr>=FIFO->TotalSize)
			{
				FIFO->WritePtr=0;
			}
			CriticalIn;
			FIFO->UnWritedCount--;
			FIFO->UnReadedCount++;
			CriticalOut;
		}
//		if(IsSafe)
//		{
//			CriticalOut;
//		}
	}
	return WriteSize;
}
